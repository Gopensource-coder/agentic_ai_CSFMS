import json
import math
import random
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.cm as cm
from matplotlib import rcParams
from mpl_toolkits.mplot3d import Axes3D
from dataclasses import dataclass
from typing import List, Dict, Tuple, Optional
from collections import defaultdict

NUM_OBJECTIVES = 3

OBJECTIVE_NAMES = [
    "Makespan (last storage delivery time)",
    "Total Energy Consumption (kWh)",
    "Maximum Worker Fatigue [0, 1)",
]


@dataclass
class Operation:
    job_id: int
    op_id: int
    eligible_machines: List[int]
    processing_times: Dict[int, float]
    setup_time: float
    is_storage: bool = False


@dataclass
class Job:
    job_id: int
    operations: List[Operation]
    priority: int = 1
    due_date: float = float('inf')


@dataclass
class Machine:
    machine_id: int
    name: str
    location: Tuple[float, float]
    power_kw: float = 1.0


@dataclass
class AGV:
    agv_id: int
    speed: float = 1.0
    capacity: int = 1
    power_kw: float = 0.5


@dataclass
class Worker:
    worker_id: int
    skills: List[int]
    efficiency: float = 1.0


@dataclass
class ScheduleTask:
    job_id: int
    op_id: int
    machine_id: int
    worker_id: int
    agv_id: int
    start_time: float
    setup_start: float
    setup_end: float
    processing_start: float
    processing_end: float
    empty_travel_start: float
    empty_travel_end: float
    loaded_travel_start: float
    loaded_travel_end: float
    is_storage: bool = False


class FMSProblem:
    STORAGE_MACHINE_ID:   int = -2
    ENTRANCE_LOCATION_ID: int = -1

    def __init__(self):
        self.jobs: List[Job]         = []
        self.machines: List[Machine] = []
        self.agvs: List[AGV]         = []
        self.workers: List[Worker]   = []
        self.storage_location: Tuple[float, float]  = (50.0, 100.0)
        self.entrance_location: Tuple[float, float] = (0.0,  0.0)
        self.fatigue_theta: float = 0.01

    def get_location(self, location_id: int) -> Tuple[float, float]:
        if location_id == self.ENTRANCE_LOCATION_ID:
            return self.entrance_location
        if location_id == self.STORAGE_MACHINE_ID:
            return self.storage_location
        return self.machines[location_id].location

    def get_transport_time(self, from_loc: int, to_loc: int, agv: AGV) -> float:
        src  = self.get_location(from_loc)
        dst  = self.get_location(to_loc)
        dist = math.sqrt((src[0] - dst[0]) ** 2 + (src[1] - dst[1]) ** 2)
        return dist / 20.0 / agv.speed

    def get_total_operations(self, include_storage: bool = True) -> int:
        if include_storage:
            return sum(len(j.operations) for j in self.jobs)
        return sum(len(j.operations) - 1 for j in self.jobs)


def parse_problem_from_json(json_data) -> FMSProblem:
    if isinstance(json_data, str):
        try:
            data = json.loads(json_data)
        except json.JSONDecodeError as exc:
            raise ValueError(f"Invalid JSON string: {exc}") from exc
    elif isinstance(json_data, dict):
        data = json_data
    else:
        raise ValueError(f"json_data must be str or dict, got {type(json_data)}")

    problem = FMSProblem()

    if "storage_location" in data:
        sl = data["storage_location"]
        problem.storage_location = (float(sl[0]), float(sl[1]))
    if "entrance_location" in data:
        el = data["entrance_location"]
        problem.entrance_location = (float(el[0]), float(el[1]))
    if "fatigue_theta" in data:
        theta = float(data["fatigue_theta"])
        if theta <= 0:
            raise ValueError("fatigue_theta must be positive.")
        problem.fatigue_theta = theta

    if not data.get("machines"):
        raise ValueError("JSON must contain a non-empty 'machines' list.")
    for m in data["machines"]:
        mid = int(m["machine_id"])
        loc = m.get("location", [0.0, 0.0])
        problem.machines.append(Machine(
            machine_id=mid,
            name=str(m.get("name", f"Machine_{mid}")),
            location=(float(loc[0]), float(loc[1])),
            power_kw=float(m.get("power_kw", 1.0)),
        ))
    machine_id_set = {mach.machine_id for mach in problem.machines}

    if not data.get("agvs"):
        raise ValueError("JSON must contain a non-empty 'agvs' list.")
    for a in data["agvs"]:
        problem.agvs.append(AGV(
            agv_id=int(a["agv_id"]),
            speed=float(a.get("speed", 1.0)),
            capacity=int(a.get("capacity", 1)),
            power_kw=float(a.get("power_kw", 0.5)),
        ))

    if not data.get("workers"):
        raise ValueError("JSON must contain a non-empty 'workers' list.")
    for w in data["workers"]:
        problem.workers.append(Worker(
            worker_id=int(w["worker_id"]),
            skills=[int(s) for s in w.get("skills", [])],
            efficiency=float(w.get("efficiency", 1.0)),
        ))

    if not data.get("jobs"):
        raise ValueError("JSON must contain a non-empty 'jobs' list.")
    for j in data["jobs"]:
        job_id   = int(j["job_id"])
        priority = int(j.get("priority", 1))
        raw_due  = j.get("due_date")
        due_date = float(raw_due) if raw_due is not None else float('inf')
        if not j.get("operations"):
            raise ValueError(f"Job {job_id} must have a non-empty 'operations' list.")
        operations: List[Operation] = []
        has_storage = False
        for op_data in j["operations"]:
            op_id      = int(op_data["op_id"])
            is_storage = bool(op_data.get("is_storage", False))
            if is_storage:
                eligible   = [FMSProblem.STORAGE_MACHINE_ID]
                proc_times = {FMSProblem.STORAGE_MACHINE_ID: 0.0}
                setup      = 0.0
                has_storage = True
            else:
                eligible = [int(x) for x in op_data.get("eligible_machines", [])]
                if not eligible:
                    raise ValueError(f"Job {job_id}, Op {op_id}: 'eligible_machines' is empty.")
                for mid in eligible:
                    if mid not in machine_id_set:
                        raise ValueError(f"Job {job_id}, Op {op_id}: machine_id {mid} not found.")
                proc_times = {int(k): float(v)
                              for k, v in op_data.get("processing_times", {}).items()}
                if not proc_times:
                    raise ValueError(f"Job {job_id}, Op {op_id}: 'processing_times' is empty.")
                setup = float(op_data.get("setup_time", 0.0))
            operations.append(Operation(job_id, op_id, eligible, proc_times, setup, is_storage))
        if not has_storage:
            sid = len(operations)
            operations.append(Operation(
                job_id=job_id, op_id=sid,
                eligible_machines=[FMSProblem.STORAGE_MACHINE_ID],
                processing_times={FMSProblem.STORAGE_MACHINE_ID: 0.0},
                setup_time=0.0, is_storage=True,
            ))
        problem.jobs.append(Job(job_id, operations, priority, due_date))

    return problem


def parse_hyperparams_from_json(json_data) -> dict:
    if isinstance(json_data, str):
        try:
            data = json.loads(json_data)
        except json.JSONDecodeError as exc:
            raise ValueError(f"Invalid JSON string: {exc}") from exc
    elif isinstance(json_data, dict):
        data = json_data
    else:
        raise ValueError(f"json_data must be str or dict, got {type(json_data)}")

    defaults = {
        "population_size"    : 100,
        "generations"        : 200,
        "crossover_rate"     : 0.9,
        "mutation_rate"      : 0.1,
        "num_divisions"      : 12,
        "reference_points"   : None,
        "objective_weights"  : [1.0 / NUM_OBJECTIVES] * NUM_OBJECTIVES,
        "random_seed"        : None,
        "verbose"            : True,
    }
    params = {k: data.get(k, v) for k, v in defaults.items()}

    params["population_size"]   = int(params["population_size"])
    params["generations"]       = int(params["generations"])
    params["crossover_rate"]    = float(params["crossover_rate"])
    params["mutation_rate"]     = float(params["mutation_rate"])
    params["num_divisions"]     = int(params["num_divisions"])
    params["verbose"]           = bool(params["verbose"])
    params["objective_weights"] = [float(w) for w in params["objective_weights"]]
    if params["random_seed"] is not None:
        params["random_seed"] = int(params["random_seed"])
    if params["reference_points"] is not None:
        params["reference_points"] = [
            [float(v) for v in rp] for rp in params["reference_points"]
        ]

    if params["population_size"] < 4:
        raise ValueError("population_size must be >= 4.")
    if params["generations"] < 1:
        raise ValueError("generations must be >= 1.")
    for key in ("crossover_rate", "mutation_rate"):
        if not (0.0 <= params[key] <= 1.0):
            raise ValueError(f"{key} must be in [0, 1].")
    if params["num_divisions"] < 1:
        raise ValueError("num_divisions must be >= 1.")
    if len(params["objective_weights"]) != NUM_OBJECTIVES:
        raise ValueError(f"objective_weights must have {NUM_OBJECTIVES} elements.")
    if sum(params["objective_weights"]) <= 0:
        raise ValueError("objective_weights must sum to a positive value.")

    return params


class Chromosome:
    def __init__(self, problem: FMSProblem):
        self.problem = problem
        self.operation_sequence: List[Tuple[int, int]] = []
        self.machine_assignment: Dict[Tuple[int, int], int] = {}
        self.worker_assignment:  Dict[Tuple[int, int], int] = {}
        self.agv_assignment:     Dict[Tuple[int, int], int] = {}
        self.schedule: List[ScheduleTask] = []

        self.objectives:           List[float] = [float('inf')] * NUM_OBJECTIVES
        self.constraint_violation: float       = float('inf')
        self.rank:                 int         = 0
        self.ref_point_idx:        int         = -1
        self.perpendicular_dist:   float       = float('inf')

    @property
    def fitness(self) -> float:
        return sum(self.objectives)

    def initialize_random(self):
        all_ops = [
            (job.job_id, op.op_id)
            for job in self.problem.jobs
            for op in job.operations
        ]
        random.shuffle(all_ops)
        self.operation_sequence = all_ops

        for job in self.problem.jobs:
            for op in job.operations:
                key = (op.job_id, op.op_id)
                if op.is_storage:
                    self.machine_assignment[key] = FMSProblem.STORAGE_MACHINE_ID
                else:
                    self.machine_assignment[key] = random.choice(op.eligible_machines)

        for job in self.problem.jobs:
            for op in job.operations:
                key = (op.job_id, op.op_id)
                if op.is_storage:
                    self.worker_assignment[key] = -1
                else:
                    mid     = self.machine_assignment[key]
                    skilled = [w for w in self.problem.workers if mid in w.skills]
                    self.worker_assignment[key] = (
                        random.choice(skilled).worker_id if skilled
                        else random.choice(self.problem.workers).worker_id
                    )

        for job in self.problem.jobs:
            for op in job.operations:
                key = (op.job_id, op.op_id)
                self.agv_assignment[key] = random.choice(self.problem.agvs).agv_id

    def copy(self) -> 'Chromosome':
        clone = Chromosome(self.problem)
        clone.operation_sequence   = self.operation_sequence.copy()
        clone.machine_assignment   = self.machine_assignment.copy()
        clone.worker_assignment    = self.worker_assignment.copy()
        clone.agv_assignment       = self.agv_assignment.copy()
        clone.schedule             = self.schedule.copy()
        clone.objectives           = self.objectives.copy()
        clone.constraint_violation = self.constraint_violation
        clone.rank                 = self.rank
        clone.ref_point_idx        = self.ref_point_idx
        clone.perpendicular_dist   = self.perpendicular_dist
        return clone


class Decoder:
    def __init__(self, problem: FMSProblem):
        self.problem      = problem
        self._machine_map = {m.machine_id: m for m in problem.machines}
        self._agv_map     = {a.agv_id:     a for a in problem.agvs}
        self._worker_map  = {w.worker_id:  w for w in problem.workers}

    def decode(
        self, chromosome: Chromosome
    ) -> Tuple[List[float], float, List[ScheduleTask]]:
        machine_avail: Dict[int, float] = {
            m.machine_id: 0.0 for m in self.problem.machines
        }
        worker_avail: Dict[int, float] = {
            w.worker_id: 0.0 for w in self.problem.workers
        }
        agv_avail: Dict[int, float] = {
            a.agv_id: 0.0 for a in self.problem.agvs
        }
        agv_loc: Dict[int, int] = {
            a.agv_id: FMSProblem.ENTRANCE_LOCATION_ID for a in self.problem.agvs
        }
        job_finish:       Dict[int, float] = {j.job_id: 0.0 for j in self.problem.jobs}
        job_last_machine: Dict[int, int]   = {
            j.job_id: FMSProblem.ENTRANCE_LOCATION_ID for j in self.problem.jobs
        }
        job_op_count: Dict[int, int]         = {j.job_id: 0 for j in self.problem.jobs}
        schedule: List[ScheduleTask]         = []
        constraint_violation: float          = 0.0
        total_energy: float                  = 0.0
        worker_setup_total: Dict[int, float] = defaultdict(float)

        for job_id, op_id in chromosome.operation_sequence:
            job = self.problem.jobs[job_id]
            op  = job.operations[op_id]

            if op_id != job_op_count[job_id]:
                constraint_violation += 1000.0
                continue

            key        = (job_id, op_id)
            machine_id = chromosome.machine_assignment[key]
            worker_id  = chromosome.worker_assignment[key]
            agv_id     = chromosome.agv_assignment[key]
            agv        = self._agv_map[agv_id]

            if op.is_storage:
                last_loc = job_last_machine[job_id]
                empty_t  = self.problem.get_transport_time(agv_loc[agv_id], last_loc, agv)
                loaded_t = self.problem.get_transport_time(
                    last_loc, FMSProblem.STORAGE_MACHINE_ID, agv)
                ets = max(agv_avail[agv_id], job_finish[job_id])
                ete = ets + empty_t
                lts = ete
                lte = lts + loaded_t
                agv_avail[agv_id]         = lte
                agv_loc[agv_id]           = FMSProblem.STORAGE_MACHINE_ID
                job_finish[job_id]        = lte
                job_last_machine[job_id]  = FMSProblem.STORAGE_MACHINE_ID
                job_op_count[job_id]     += 1
                total_energy             += (empty_t + loaded_t) * agv.power_kw
                schedule.append(ScheduleTask(
                    job_id=job_id, op_id=op_id,
                    machine_id=machine_id, worker_id=worker_id, agv_id=agv_id,
                    start_time=ets,
                    setup_start=lte, setup_end=lte,
                    processing_start=lte, processing_end=lte,
                    empty_travel_start=ets, empty_travel_end=ete,
                    loaded_travel_start=lts, loaded_travel_end=lte,
                    is_storage=True,
                ))
                continue

            worker  = self._worker_map[worker_id]
            machine = self._machine_map[machine_id]

            if machine_id not in op.eligible_machines:
                constraint_violation += 500.0
                processing_time = max(op.processing_times.values()) * 2.0
            else:
                processing_time = op.processing_times[machine_id]

            if machine_id not in worker.skills:
                constraint_violation += 200.0
                efficiency = 0.5
            else:
                efficiency = worker.efficiency

            actual_setup = op.setup_time / efficiency
            last_loc     = job_last_machine[job_id]
            empty_t  = self.problem.get_transport_time(agv_loc[agv_id], last_loc, agv)
            loaded_t = self.problem.get_transport_time(last_loc, machine_id, agv)

            ets     = max(agv_avail[agv_id], job_finish[job_id])
            ete     = ets + empty_t
            lts     = ete
            lte     = lts + loaded_t
            setup_s = max(lte, worker_avail[worker_id], machine_avail[machine_id])
            setup_e = setup_s + actual_setup
            proc_s  = setup_e
            proc_e  = proc_s + processing_time

            machine_avail[machine_id]     = proc_e
            worker_avail[worker_id]       = setup_e
            agv_avail[agv_id]             = lte
            agv_loc[agv_id]               = machine_id
            job_finish[job_id]            = proc_e
            job_last_machine[job_id]      = machine_id
            job_op_count[job_id]         += 1
            worker_setup_total[worker_id] += actual_setup
            total_energy += processing_time * machine.power_kw
            total_energy += (empty_t + loaded_t) * agv.power_kw

            schedule.append(ScheduleTask(
                job_id=job_id, op_id=op_id,
                machine_id=machine_id, worker_id=worker_id, agv_id=agv_id,
                start_time=ets,
                setup_start=setup_s, setup_end=setup_e,
                processing_start=proc_s, processing_end=proc_e,
                empty_travel_start=ets, empty_travel_end=ete,
                loaded_travel_start=lts, loaded_travel_end=lte,
                is_storage=False,
            ))

        storage_ends = [t.loaded_travel_end for t in schedule if t.is_storage]
        makespan     = max(storage_ends) if storage_ends else (
            max(job_finish.values()) if job_finish else 0.0
        )
        energy       = total_energy
        theta        = self.problem.fatigue_theta
        if worker_setup_total:
            t_max   = max(worker_setup_total.values())
            fatigue = 1.0 - math.exp(-theta * t_max)
        else:
            fatigue = 0.0

        return [makespan, energy, fatigue], constraint_violation, schedule


class GeneticOperators:
    def __init__(self, problem: FMSProblem):
        self.problem = problem

    def crossover_pox(
        self, parent1: Chromosome, parent2: Chromosome
    ) -> Tuple[Chromosome, Chromosome]:
        child1 = Chromosome(self.problem)
        child2 = Chromosome(self.problem)

        job_ids  = [j.job_id for j in self.problem.jobs]
        preserve = set(random.sample(job_ids, random.randint(1, len(job_ids) - 1)))

        def _build_seq(primary, secondary, kept):
            tail = [(j, o) for j, o in secondary.operation_sequence if j not in kept]
            result, idx = [], 0
            for j, o in primary.operation_sequence:
                if j in kept:
                    result.append((j, o))
                elif idx < len(tail):
                    result.append(tail[idx])
                    idx += 1
            result.extend(tail[idx:])
            return result

        child1.operation_sequence = _build_seq(parent1, parent2, preserve)
        child2.operation_sequence = _build_seq(parent2, parent1, preserve)

        for key in parent1.machine_assignment:
            job_id, op_id = key
            op = self.problem.jobs[job_id].operations[op_id]
            if op.is_storage:
                child1.machine_assignment[key] = FMSProblem.STORAGE_MACHINE_ID
                child2.machine_assignment[key] = FMSProblem.STORAGE_MACHINE_ID
                child1.worker_assignment[key]  = -1
                child2.worker_assignment[key]  = -1
            else:
                if random.random() < 0.5:
                    child1.machine_assignment[key] = parent1.machine_assignment[key]
                    child1.worker_assignment[key]  = parent1.worker_assignment[key]
                    child2.machine_assignment[key] = parent2.machine_assignment[key]
                    child2.worker_assignment[key]  = parent2.worker_assignment[key]
                else:
                    child1.machine_assignment[key] = parent2.machine_assignment[key]
                    child1.worker_assignment[key]  = parent2.worker_assignment[key]
                    child2.machine_assignment[key] = parent1.machine_assignment[key]
                    child2.worker_assignment[key]  = parent1.worker_assignment[key]
            if random.random() < 0.5:
                child1.agv_assignment[key] = parent1.agv_assignment[key]
                child2.agv_assignment[key] = parent2.agv_assignment[key]
            else:
                child1.agv_assignment[key] = parent2.agv_assignment[key]
                child2.agv_assignment[key] = parent1.agv_assignment[key]

        return child1, child2

    def mutation_swap(
        self, chromosome: Chromosome, mutation_rate: float = 0.1
    ) -> Chromosome:
        chrome = chromosome.copy()

        if random.random() < mutation_rate:
            n = len(chrome.operation_sequence)
            if n >= 2:
                i, j = random.sample(range(n), 2)
                chrome.operation_sequence[i], chrome.operation_sequence[j] = (
                    chrome.operation_sequence[j], chrome.operation_sequence[i]
                )
        for key in chrome.machine_assignment:
            jid, oid = key
            op = self.problem.jobs[jid].operations[oid]
            if not op.is_storage and random.random() < mutation_rate:
                chrome.machine_assignment[key] = random.choice(op.eligible_machines)
        for key in chrome.worker_assignment:
            jid, oid = key
            op = self.problem.jobs[jid].operations[oid]
            if not op.is_storage and random.random() < mutation_rate:
                mid     = chrome.machine_assignment[key]
                skilled = [w for w in self.problem.workers if mid in w.skills]
                if skilled:
                    chrome.worker_assignment[key] = random.choice(skilled).worker_id
        for key in chrome.agv_assignment:
            if random.random() < mutation_rate:
                chrome.agv_assignment[key] = random.choice(self.problem.agvs).agv_id

        return chrome

    def repair_sequence(self, chromosome: Chromosome) -> Chromosome:
        chrome = chromosome.copy()
        job_slots: Dict[int, List[Tuple[int, int]]] = defaultdict(list)
        for idx, (job_id, op_id) in enumerate(chrome.operation_sequence):
            job_slots[job_id].append((idx, op_id))
        new_seq = list(chrome.operation_sequence)
        for job_id, slot_list in job_slots.items():
            slot_list.sort(key=lambda x: x[1])
            positions = sorted(pos for pos, _ in slot_list)
            for pos, (_, op_id) in zip(positions, slot_list):
                new_seq[pos] = (job_id, op_id)
        chrome.operation_sequence = new_seq
        return chrome


def _generate_reference_points(num_objectives: int, num_divisions: int) -> np.ndarray:
    def _recurse(num_obj, num_div, current, start, result):
        if num_obj == 1:
            current.append(num_div - start)
            result.append(current[:])
            current.pop()
            return
        for i in range(num_div - start + 1):
            current.append(i)
            _recurse(num_obj - 1, num_div, current, start + i, result)
            current.pop()

    result = []
    _recurse(num_objectives, num_divisions, [], 0, result)
    ref_points = np.array(result, dtype=float) / num_divisions
    return ref_points


def _associate_to_reference_points(
    pop: List[Chromosome],
    ref_points: np.ndarray,
    ideal_point: np.ndarray,
    nadir_point: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray]:
    obj_matrix = np.array([c.objectives for c in pop], dtype=float)
    range_vec  = nadir_point - ideal_point
    range_vec  = np.where(range_vec < 1e-10, 1.0, range_vec)
    norm_matrix = (obj_matrix - ideal_point) / range_vec

    n_pop = len(pop)
    n_ref = len(ref_points)
    assoc_rp   = np.full(n_pop, -1, dtype=int)
    perp_dists = np.full(n_pop, float('inf'))

    ref_norms = np.linalg.norm(ref_points, axis=1, keepdims=True)
    ref_unit  = ref_points / np.where(ref_norms < 1e-12, 1.0, ref_norms)

    for i, nv in enumerate(norm_matrix):
        best_rp   = -1
        best_dist = float('inf')
        for r in range(n_ref):
            proj   = np.dot(nv, ref_unit[r])
            d_perp = math.sqrt(max(0.0, np.dot(nv, nv) - proj * proj))
            if d_perp < best_dist:
                best_dist = d_perp
                best_rp   = r
        assoc_rp[i]   = best_rp
        perp_dists[i] = best_dist
        pop[i].ref_point_idx      = int(best_rp)
        pop[i].perpendicular_dist = float(best_dist)

    return assoc_rp, perp_dists


class NSGA3:
    def __init__(
        self,
        problem: FMSProblem,
        population_size: int    = 100,
        generations: int        = 200,
        crossover_rate: float   = 0.9,
        mutation_rate: float    = 0.1,
        num_divisions: int      = 12,
        reference_points: Optional[np.ndarray] = None,
    ):
        self.problem         = problem
        self.population_size = population_size
        self.generations     = generations
        self.crossover_rate  = crossover_rate
        self.mutation_rate   = mutation_rate

        if reference_points is not None:
            self.ref_points = np.array(reference_points, dtype=float)
        else:
            self.ref_points = _generate_reference_points(NUM_OBJECTIVES, num_divisions)

        self.num_divisions = num_divisions
        self.decoder   = Decoder(problem)
        self.operators = GeneticOperators(problem)

        self.population: List[Chromosome]   = []
        self.pareto_front: List[Chromosome] = []

        self.history: Dict[str, List] = {
            'pareto_size': [],
            'min_f1':      [],
            'min_f2':      [],
            'min_f3':      [],
        }

    def _init_population(self):
        self.population = []
        for _ in range(self.population_size):
            c = Chromosome(self.problem)
            c.initialize_random()
            c = self.operators.repair_sequence(c)
            self.population.append(c)

    def _eval(self, c: Chromosome):
        objs, cv, sched        = self.decoder.decode(c)
        c.objectives           = objs
        c.constraint_violation = cv
        c.schedule             = sched

    def _eval_population(self, pop: List[Chromosome]):
        for c in pop:
            self._eval(c)

    def _dominates(self, a: Chromosome, b: Chromosome) -> bool:
        cv_a, cv_b = a.constraint_violation, b.constraint_violation
        if cv_a == 0.0 and cv_b > 0.0:
            return True
        if cv_a > 0.0 and cv_b == 0.0:
            return False
        if cv_a > 0.0 and cv_b > 0.0:
            return cv_a < cv_b
        strictly_better = False
        for oa, ob in zip(a.objectives, b.objectives):
            if oa > ob:
                return False
            if oa < ob:
                strictly_better = True
        return strictly_better

    def _fast_non_dominated_sort(
        self, pop: List[Chromosome]
    ) -> List[List[Chromosome]]:
        n          = len(pop)
        dom_count  = [0] * n
        dom_set    = [[] for _ in range(n)]
        fronts: List[List[int]] = [[]]

        for i in range(n):
            for j in range(n):
                if i == j:
                    continue
                if self._dominates(pop[i], pop[j]):
                    dom_set[i].append(j)
                elif self._dominates(pop[j], pop[i]):
                    dom_count[i] += 1
            if dom_count[i] == 0:
                pop[i].rank = 0
                fronts[0].append(i)

        k = 0
        while fronts[k]:
            nxt: List[int] = []
            for i in fronts[k]:
                for j in dom_set[i]:
                    dom_count[j] -= 1
                    if dom_count[j] == 0:
                        pop[j].rank = k + 1
                        nxt.append(j)
            fronts.append(nxt)
            k += 1

        return [[pop[i] for i in f] for f in fronts if f]

    def _compute_ideal_nadir(
        self, pop: List[Chromosome]
    ) -> Tuple[np.ndarray, np.ndarray]:
        obj_matrix = np.array([c.objectives for c in pop], dtype=float)
        ideal      = obj_matrix.min(axis=0)
        nadir      = obj_matrix.max(axis=0)
        return ideal, nadir

    def _niche_selection(
        self,
        already_selected: List[Chromosome],
        critical_front: List[Chromosome],
        slots_needed: int,
        ideal_point: np.ndarray,
        nadir_point: np.ndarray,
    ) -> List[Chromosome]:
        combined        = already_selected + critical_front
        assoc_all, _    = _associate_to_reference_points(
            combined, self.ref_points, ideal_point, nadir_point
        )
        n_already       = len(already_selected)
        n_ref           = len(self.ref_points)

        rho: Dict[int, int] = defaultdict(int)
        for i in range(n_already):
            rho[int(assoc_all[i])] += 1

        critical_assoc = assoc_all[n_already:]
        critical_dists = np.array([c.perpendicular_dist for c in critical_front])

        selected_flags = [False] * len(critical_front)
        selected       = []

        for _ in range(slots_needed):
            min_count = min(rho[r] for r in range(n_ref))
            candidate_rps = [r for r in range(n_ref) if rho[r] == min_count]

            chosen_rp   = random.choice(candidate_rps)
            members_idx = [
                i for i in range(len(critical_front))
                if (not selected_flags[i]) and (int(critical_assoc[i]) == chosen_rp)
            ]

            if not members_idx:
                remaining = [
                    i for i in range(len(critical_front)) if not selected_flags[i]
                ]
                if not remaining:
                    break
                chosen_idx = min(remaining, key=lambda i: critical_dists[i])
            elif rho[chosen_rp] == 0:
                chosen_idx = min(members_idx, key=lambda i: critical_dists[i])
            else:
                chosen_idx = random.choice(members_idx)

            selected_flags[chosen_idx] = True
            selected.append(critical_front[chosen_idx])
            rho[int(critical_assoc[chosen_idx])] += 1

        return selected

    def _tournament_selection(self, pop: List[Chromosome]) -> Chromosome:
        a, b = random.sample(pop, 2)
        if a.rank < b.rank:
            return a
        if b.rank < a.rank:
            return b
        if a.perpendicular_dist < b.perpendicular_dist:
            return a
        return b

    def evolve(self, verbose: bool = True) -> List[Chromosome]:
        self._init_population()
        self._eval_population(self.population)

        init_fronts = self._fast_non_dominated_sort(self.population)
        ideal, nadir = self._compute_ideal_nadir(self.population)
        _associate_to_reference_points(self.population, self.ref_points, ideal, nadir)

        for gen in range(self.generations):
            offspring: List[Chromosome] = []
            while len(offspring) < self.population_size:
                p1 = self._tournament_selection(self.population)
                p2 = self._tournament_selection(self.population)
                if random.random() < self.crossover_rate:
                    c1, c2 = self.operators.crossover_pox(p1, p2)
                else:
                    c1, c2 = p1.copy(), p2.copy()
                c1 = self.operators.mutation_swap(c1, self.mutation_rate)
                c2 = self.operators.mutation_swap(c2, self.mutation_rate)
                c1 = self.operators.repair_sequence(c1)
                c2 = self.operators.repair_sequence(c2)
                offspring.extend([c1, c2])
            offspring = offspring[:self.population_size]
            self._eval_population(offspring)

            combined     = self.population + offspring
            all_fronts   = self._fast_non_dominated_sort(combined)
            ideal, nadir = self._compute_ideal_nadir(combined)

            next_pop: List[Chromosome] = []
            for front in all_fronts:
                slots = self.population_size - len(next_pop)
                if slots <= 0:
                    break
                if len(front) <= slots:
                    next_pop.extend(front)
                else:
                    chosen = self._niche_selection(
                        next_pop, front, slots, ideal, nadir
                    )
                    next_pop.extend(chosen)
                    break

            _associate_to_reference_points(next_pop, self.ref_points, ideal, nadir)
            self.population = next_pop

            curr_fronts = self._fast_non_dominated_sort(self.population)
            curr_pareto = curr_fronts[0] if curr_fronts else []

            self.history['pareto_size'].append(len(curr_pareto))
            if curr_pareto:
                self.history['min_f1'].append(min(c.objectives[0] for c in curr_pareto))
                self.history['min_f2'].append(min(c.objectives[1] for c in curr_pareto))
                self.history['min_f3'].append(min(c.objectives[2] for c in curr_pareto))
            else:
                for key in ('min_f1', 'min_f2', 'min_f3'):
                    self.history[key].append(float('inf'))

            if verbose and (gen + 1) % 10 == 0:
                print(
                    f"Gen {gen + 1:>4}/{self.generations} | "
                    f"Pareto: {len(curr_pareto):>3} | "
                    f"f1(makespan) = {self.history['min_f1'][-1]:>8.2f} | "
                    f"f2(energy)   = {self.history['min_f2'][-1]:>8.3f} | "
                    f"f3(fatigue)  = {self.history['min_f3'][-1]:>7.5f}"
                )

        final_fronts      = self._fast_non_dominated_sort(self.population)
        self.pareto_front = final_fronts[0] if final_fronts else []
        return self.pareto_front

    def get_compromise_solution(
        self,
        pareto_front: Optional[List[Chromosome]] = None,
        weights: Optional[List[float]] = None,
    ) -> Optional[Chromosome]:
        front = pareto_front if pareto_front is not None else self.pareto_front
        if not front:
            return None
        if len(front) == 1:
            return front[0]
        if weights is None:
            weights = [1.0 / NUM_OBJECTIVES] * NUM_OBJECTIVES

        obj_min = [min(c.objectives[i] for c in front) for i in range(NUM_OBJECTIVES)]
        obj_max = [max(c.objectives[i] for c in front) for i in range(NUM_OBJECTIVES)]

        best_sol, best_score = None, float('inf')
        for c in front:
            score = sum(
                weights[i] * ((c.objectives[i] - obj_min[i]) /
                              (obj_max[i] - obj_min[i]) if obj_max[i] > obj_min[i] else 0.0)
                for i in range(NUM_OBJECTIVES)
            )
            if score < best_score:
                best_score = score
                best_sol   = c
        return best_sol

    def plot_pareto_front(self, save_path: Optional[str] = None):
        if not self.pareto_front:
            print("Pareto front is empty.")
            return

        rcParams["font.family"] = "Times New Roman"
        front   = self.pareto_front
        f1_vals = [c.objectives[0] for c in front]
        f2_vals = [c.objectives[1] for c in front]
        f3_vals = [c.objectives[2] for c in front]

        comp = self.get_compromise_solution()
        cx = comp.objectives[0] if comp else None
        cy = comp.objectives[1] if comp else None
        cz = comp.objectives[2] if comp else None

        rp_idx  = np.array([c.ref_point_idx for c in front], dtype=float)
        colours = cm.tab20(rp_idx % 20 / 20.0)

        fig = plt.figure(figsize=(14, 12))
        fig.suptitle(
            f"NSGA-III Pareto Front  —  FMS Scheduling\n"
            f"(H={self.num_divisions}, ref_points={len(self.ref_points)})",
            fontsize=13
        )

        ax3d = fig.add_subplot(2, 2, 1, projection='3d')
        ax3d.scatter(f1_vals, f2_vals, f3_vals, c=colours, s=40, depthshade=True)
        if cx is not None:
            ax3d.scatter([cx], [cy], [cz], c='red', s=180, marker='*',
                         label='Compromise', zorder=5)
        rp_norm  = self.ref_points
        rp_scale = np.array([
            max(f1_vals) - min(f1_vals),
            max(f2_vals) - min(f2_vals),
            max(f3_vals) - min(f3_vals),
        ])
        rp_offset = np.array([min(f1_vals), min(f2_vals), min(f3_vals)])
        rp_scaled = rp_norm * rp_scale + rp_offset
        ax3d.scatter(rp_scaled[:, 0], rp_scaled[:, 1], rp_scaled[:, 2],
                     c='grey', s=10, alpha=0.4, marker='x', label='Ref. Points')
        ax3d.set_xlabel("f1 Makespan",      fontsize=8)
        ax3d.set_ylabel("f2 Energy (kWh)",  fontsize=8)
        ax3d.set_zlabel("f3 Fatigue [0,1)", fontsize=8)
        ax3d.set_title("3-D Pareto Front", fontsize=10)
        ax3d.legend(fontsize=7)

        xy_data = [f1_vals, f2_vals, f3_vals]
        c_data  = [cx, cy, cz]
        projs   = [
            (222, 0, 1, "f1 Makespan",     "f2 Energy (kWh)"),
            (223, 0, 2, "f1 Makespan",     "f3 Fatigue [0,1)"),
            (224, 1, 2, "f2 Energy (kWh)", "f3 Fatigue [0,1)"),
        ]
        for pos, xi, yi, xlabel, ylabel in projs:
            ax = fig.add_subplot(pos)
            ax.scatter(xy_data[xi], xy_data[yi], c=colours, s=30, alpha=0.85)
            if c_data[xi] is not None:
                ax.scatter(c_data[xi], c_data[yi], c='red', s=140,
                           marker='*', zorder=5, label='Compromise')
            ax.set_xlabel(xlabel, fontsize=9)
            ax.set_ylabel(ylabel, fontsize=9)
            ax.set_title(f"{xlabel}  vs  {ylabel}", fontsize=10)
            ax.grid(True, alpha=0.3)
            ax.legend(fontsize=8)

        plt.tight_layout(rect=[0, 0, 1.0, 0.97])
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
        plt.show()

    def plot_convergence(self, save_path: Optional[str] = None):
        if not any(v for v in self.history.values()):
            print("No convergence history to plot.")
            return

        rcParams["font.family"] = "Times New Roman"
        gens = range(1, len(self.history['pareto_size']) + 1)
        fig, axes = plt.subplots(2, 2, figsize=(12, 8), sharex=True)
        fig.suptitle(
            f"NSGA-III Convergence History  —  FMS Scheduling\n"
            f"(H={self.num_divisions}, ref_points={len(self.ref_points)})",
            fontsize=12
        )
        panels = [
            (axes[0, 0], 'pareto_size', 'Pareto Front Size',       'Solutions',       'steelblue'),
            (axes[0, 1], 'min_f1',      'Best Makespan (f1)',       'Time',            'darkorange'),
            (axes[1, 0], 'min_f2',      'Best Energy (f2)  [kWh]', 'Energy',          'seagreen'),
            (axes[1, 1], 'min_f3',      'Best Worker Fatigue (f3)', 'Fatigue  [0,1)',  'orchid'),
        ]
        for ax, key, title, ylabel, colour in panels:
            vals = self.history[key]
            ax.plot(gens, vals, color=colour, linewidth=1.6)
            ax.fill_between(gens, vals, alpha=0.15, color=colour)
            ax.set_title(title, fontsize=10)
            ax.set_ylabel(ylabel, fontsize=9)
            ax.grid(True, alpha=0.3)
        for ax in axes[1]:
            ax.set_xlabel('Generation', fontsize=9)
        plt.tight_layout()
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
        plt.show()

    def plot_gantt(
        self,
        solution: Optional[Chromosome] = None,
        save_path: Optional[str] = None,
        title_suffix: str = "",
    ):
        sol = solution or self.get_compromise_solution()
        if sol is None or not sol.schedule:
            print("No solution / schedule to plot.")
            return

        rcParams["font.family"] = "Times New Roman"
        fig, axes = plt.subplots(3, 1, figsize=(14, 12), sharex=True)
        colours   = plt.cm.Set3(np.linspace(0, 1, len(self.problem.jobs)))

        obj_str = (
            f"f1={sol.objectives[0]:.1f}  "
            f"f2={sol.objectives[1]:.3f} kWh  "
            f"f3={sol.objectives[2]:.4f}"
        )
        fig.suptitle(
            f"FMS Schedule Gantt  [{obj_str}]{title_suffix}",
            fontsize=11, y=0.99,
        )

        ax1 = axes[0]
        for t in sol.schedule:
            if t.is_storage:
                continue
            col = colours[t.job_id]
            ax1.barh(t.machine_id, t.setup_end - t.setup_start,
                     left=t.setup_start, height=0.4,
                     color=col, alpha=0.45, edgecolor='black', linewidth=0.5)
            ax1.barh(t.machine_id, t.processing_end - t.processing_start,
                     left=t.processing_start, height=0.4,
                     color=col, edgecolor='black', linewidth=0.5,
                     label=f'Job {t.job_id + 1}' if t.op_id == 0 else '')
        ax1.set_ylabel('Machine')
        ax1.set_yticks(range(len(self.problem.machines)))
        ax1.set_yticklabels([f'M{i}' for i in range(1, len(self.problem.machines) + 1)])
        ax1.set_title('Machine Gantt  (Light: Setup,  Dark: Processing)')
        ax1.grid(True, alpha=0.3)

        ax2 = axes[1]
        for t in sol.schedule:
            if t.is_storage:
                continue
            ax2.barh(t.worker_id, t.setup_end - t.setup_start,
                     left=t.setup_start, height=0.4,
                     color=colours[t.job_id], edgecolor='black', linewidth=0.5)
        ax2.set_ylabel('Worker')
        ax2.set_yticks(range(len(self.problem.workers)))
        ax2.set_yticklabels([f'W{i}' for i in range(1, len(self.problem.workers) + 1)])
        ax2.set_title('Worker Gantt  (Setup / Preparation tasks)')
        ax2.grid(True, alpha=0.3)

        ax3 = axes[2]
        for t in sol.schedule:
            col = colours[t.job_id]
            if (t.empty_travel_end - t.empty_travel_start) > 0.01:
                ax3.barh(t.agv_id, t.empty_travel_end - t.empty_travel_start,
                         left=t.empty_travel_start, height=0.4,
                         color=col, alpha=0.3, edgecolor='black',
                         linewidth=0.5, hatch='///')
            if (t.loaded_travel_end - t.loaded_travel_start) > 0.01:
                ax3.barh(t.agv_id, t.loaded_travel_end - t.loaded_travel_start,
                         left=t.loaded_travel_start, height=0.4,
                         color=col, alpha=0.9, edgecolor='black', linewidth=0.5)
        ax3.set_ylabel('AGV')
        ax3.set_xlabel('Time')
        ax3.set_yticks(range(len(self.problem.agvs)))
        ax3.set_yticklabels([f'AGV{i}' for i in range(1, len(self.problem.agvs) + 1)])
        ax3.set_title('AGV Gantt  (Hatched: Empty travel,  Solid: Loaded travel)')
        ax3.grid(True, alpha=0.3)

        handles, labels = ax1.get_legend_handles_labels()
        deduped = {}
        for lbl, hdl in zip(labels, handles):
            if lbl not in deduped:
                deduped[lbl] = hdl
        items          = sorted(deduped.items(), key=lambda x: int(x[0].split()[1]))
        sorted_labels  = [i[0] for i in items]
        sorted_handles = [i[1] for i in items]
        fig.legend(sorted_handles, sorted_labels,
                   loc='lower center', bbox_to_anchor=(0.5, -0.02),
                   ncol=len(sorted_labels), frameon=True, fancybox=True, shadow=True)
        plt.tight_layout()
        plt.subplots_adjust(bottom=0.08)
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.show()

    def print_pareto_front(self):
        if not self.pareto_front:
            print("Pareto front is empty.")
            return
        front_sorted = sorted(self.pareto_front, key=lambda c: c.objectives[0])
        comp = self.get_compromise_solution()
        print("\n" + "=" * 105)
        print(
            f"Final NSGA-III Pareto Front  "
            f"({len(self.pareto_front)} solutions | "
            f"H={self.num_divisions}, |Z|={len(self.ref_points)})"
        )
        print("=" * 105)
        print(
            f"{'#':<5} {'Makespan':>12} {'Energy (kWh)':>14} {'Fatigue':>10}"
            f" {'CV':>8} {'RP':>5} {'Perp Dist':>12}  Note"
        )
        print("-" * 105)
        for idx, c in enumerate(front_sorted):
            note = " ← compromise" if c is comp else ""
            pd_str = f"{c.perpendicular_dist:.4f}" if c.perpendicular_dist != float('inf') else "   ∞   "
            print(
                f"{idx:<5} {c.objectives[0]:>12.2f} {c.objectives[1]:>14.4f}"
                f" {c.objectives[2]:>10.5f} {c.constraint_violation:>8.1f}"
                f" {c.ref_point_idx:>5} {pd_str:>12}{note}"
            )

    def print_schedule(self, solution: Optional[Chromosome] = None):
        sol = solution or self.get_compromise_solution()
        if sol is None:
            print("No solution found.")
            return

        print("\n" + "=" * 100)
        print("Schedule Report  (Compromise Solution)")
        print("=" * 100)
        print(f"  f1  Makespan                    : {sol.objectives[0]:.2f}")
        print(f"  f2  Total Energy (kWh)          : {sol.objectives[1]:.4f}")
        print(f"  f3  Max Worker Fatigue [0,1)     : {sol.objectives[2]:.5f}")
        print(f"  Constraint Violation             : {sol.constraint_violation:.1f}")
        print(f"  Associated Reference Point       : {sol.ref_point_idx}")
        print(f"  Perpendicular Distance           : {sol.perpendicular_dist:.4f}")

        worker_setup: Dict[int, float] = defaultdict(float)
        for t in sol.schedule:
            if not t.is_storage:
                worker_setup[t.worker_id] += t.setup_end - t.setup_start

        theta = self.problem.fatigue_theta
        print(f"\n  Worker Fatigue Breakdown  (θ = {theta}):")
        print(f"  {'Worker':<10} {'T_w (setup)':>18} {'fatigue = 1−exp(−θ·T_w)':>28}")
        print("  " + "-" * 60)
        for w in sorted(self.problem.workers, key=lambda x: x.worker_id):
            t_w   = worker_setup.get(w.worker_id, 0.0)
            fat_w = 1.0 - math.exp(-theta * t_w)
            mark  = "  ← max" if math.isclose(fat_w, sol.objectives[2], rel_tol=1e-6) else ""
            print(f"  Worker {w.worker_id:<4} {t_w:>18.2f} {fat_w:>28.5f}{mark}")

        print("\nDetailed Schedule (Processing Operations):")
        print("-" * 100)
        print(
            f"{'Job':<6}{'Op':<6}{'Machine':<10}{'Worker':<10}{'AGV':<8}"
            f"{'Empty Travel':<18}{'Loaded Travel':<18}{'Setup':<15}{'Process':<15}"
        )
        print("-" * 100)
        for t in sorted(sol.schedule, key=lambda x: x.processing_start):
            if t.is_storage:
                continue
            print(
                f"J{t.job_id:<5}O{t.op_id:<5}M{t.machine_id:<9}"
                f"W{t.worker_id:<9}A{t.agv_id:<7}"
                f"{t.empty_travel_start:>5.1f}-{t.empty_travel_end:<10.1f}"
                f"{t.loaded_travel_start:>5.1f}-{t.loaded_travel_end:<10.1f}"
                f"{t.setup_start:>5.1f}-{t.setup_end:<8.1f}"
                f"{t.processing_start:>5.1f}-{t.processing_end:<5.1f}"
            )

        print("\nStorage / Delivery Tasks:")
        print("-" * 70)
        print(f"{'Job':<6}{'AGV':<8}{'Empty Travel':<20}{'→ Storage (loaded)':<25}")
        print("-" * 70)
        for t in sorted(sol.schedule, key=lambda x: x.loaded_travel_end):
            if not t.is_storage:
                continue
            print(
                f"J{t.job_id:<5}A{t.agv_id:<7}"
                f"{t.empty_travel_start:>5.1f}-{t.empty_travel_end:<12.1f}"
                f"{t.loaded_travel_start:>5.1f}-{t.loaded_travel_end:<10.1f}"
            )

        print("\nAGV Utilisation Statistics:")
        print("-" * 50)
        agv_stats: Dict[int, Dict[str, float]] = {
            a.agv_id: {'empty': 0.0, 'loaded': 0.0} for a in self.problem.agvs
        }
        for t in sol.schedule:
            agv_stats[t.agv_id]['empty']  += t.empty_travel_end  - t.empty_travel_start
            agv_stats[t.agv_id]['loaded'] += t.loaded_travel_end - t.loaded_travel_start
        for aid, st in agv_stats.items():
            tot = st['empty'] + st['loaded']
            if tot > 0:
                print(
                    f"AGV{aid}: Empty={st['empty']:.1f}  "
                    f"Loaded={st['loaded']:.1f}  "
                    f"Load Rate={st['loaded'] / tot * 100:.1f}%"
                )


def run_fms_scheduling_agent(
    problem_json,
    hyperparams_json,
    convergence_plot_path: Optional[str] = None,
    pareto_plot_path:      Optional[str] = None,
    gantt_plot_path:       Optional[str] = None,
    print_report:          bool          = True,
) -> dict:
    try:
        problem = parse_problem_from_json(problem_json)
        params  = parse_hyperparams_from_json(hyperparams_json)

        if params["random_seed"] is not None:
            random.seed(params["random_seed"])
            np.random.seed(params["random_seed"])

        ref_points = None
        if params["reference_points"] is not None:
            ref_points = np.array(params["reference_points"], dtype=float)

        solver = NSGA3(
            problem         = problem,
            population_size = params["population_size"],
            generations     = params["generations"],
            crossover_rate  = params["crossover_rate"],
            mutation_rate   = params["mutation_rate"],
            num_divisions   = params["num_divisions"],
            reference_points= ref_points,
        )

        pareto = solver.evolve(verbose=params["verbose"])
        comp   = solver.get_compromise_solution(weights=params["objective_weights"])

        def _ser(sched: List[ScheduleTask]) -> List[dict]:
            return [
                {
                    "job_id"             : t.job_id,
                    "op_id"              : t.op_id,
                    "machine_id"         : t.machine_id,
                    "worker_id"          : t.worker_id,
                    "agv_id"             : t.agv_id,
                    "empty_travel_start" : round(t.empty_travel_start,  3),
                    "empty_travel_end"   : round(t.empty_travel_end,    3),
                    "loaded_travel_start": round(t.loaded_travel_start, 3),
                    "loaded_travel_end"  : round(t.loaded_travel_end,   3),
                    "setup_start"        : round(t.setup_start,         3),
                    "setup_end"          : round(t.setup_end,           3),
                    "processing_start"   : round(t.processing_start,    3),
                    "processing_end"     : round(t.processing_end,      3),
                    "is_storage"         : t.is_storage,
                }
                for t in sched
            ]

        pareto_records = []
        comp_idx       = None
        for idx, c in enumerate(sorted(pareto, key=lambda x: x.objectives[0])):
            pd = c.perpendicular_dist
            pareto_records.append({
                "solution_index"      : idx,
                "objectives"          : [round(o, 6) for o in c.objectives],
                "constraint_violation": round(c.constraint_violation, 3),
                "ref_point_idx"       : c.ref_point_idx,
                "perpendicular_dist"  : round(pd, 4) if pd != float('inf') else None,
                "schedule"            : _ser(c.schedule),
            })
            if comp is not None and c is comp:
                comp_idx = idx

        comp_record = None
        if comp is not None:
            comp_record = {
                "solution_index": comp_idx,
                "objectives"    : [round(o, 6) for o in comp.objectives],
                "schedule"      : _ser(comp.schedule),
            }

        result = {
            "status"              : "success",
            "error_message"       : None,
            "algorithm"           : "NSGA-III",
            "nsga3_params"        : {
                "num_divisions" : solver.num_divisions,
                "num_ref_points": len(solver.ref_points),
            },
            "problem_summary"     : {
                "num_jobs"      : len(problem.jobs),
                "num_machines"  : len(problem.machines),
                "num_agvs"      : len(problem.agvs),
                "num_workers"   : len(problem.workers),
                "total_ops"     : problem.get_total_operations(include_storage=True),
                "processing_ops": problem.get_total_operations(include_storage=False),
                "fatigue_theta" : problem.fatigue_theta,
            },
            "pareto_front_size"   : len(pareto),
            "pareto_front"        : pareto_records,
            "compromise_solution" : comp_record,
            "convergence"         : {
                "pareto_size": solver.history['pareto_size'],
                "min_f1"     : [round(v, 4) for v in solver.history['min_f1']],
                "min_f2"     : [round(v, 6) for v in solver.history['min_f2']],
                "min_f3"     : [round(v, 6) for v in solver.history['min_f3']],
            },
        }

        if print_report:
            solver.print_pareto_front()
            if comp:
                solver.print_schedule(comp)
        if convergence_plot_path:
            solver.plot_convergence(convergence_plot_path)
        if pareto_plot_path:
            solver.plot_pareto_front(pareto_plot_path)
        if gantt_plot_path and comp:
            solver.plot_gantt(comp, gantt_plot_path)

        return result

    except Exception as exc:
        return {"status": "error", "error_message": str(exc)}


if __name__ == "__main__":
    EXAMPLE_PROBLEM_JSON = json.dumps({
        "storage_location" : [50, 100],
        "entrance_location": [0, 0],
        "fatigue_theta"    : 0.02,
        "machines": [
            {"machine_id": 0, "name": "Lathe",   "location": [10, 20], "power_kw": 3.5},
            {"machine_id": 1, "name": "Mill",    "location": [30, 40], "power_kw": 5.0},
            {"machine_id": 2, "name": "Drill",   "location": [50, 60], "power_kw": 2.0},
            {"machine_id": 3, "name": "Grinder", "location": [70, 30], "power_kw": 4.0},
        ],
        "agvs": [
            {"agv_id": 0, "speed": 1.5, "power_kw": 0.8},
            {"agv_id": 1, "speed": 1.2, "power_kw": 0.6},
        ],
        "workers": [
            {"worker_id": 0, "skills": [0, 1, 2], "efficiency": 1.0},
            {"worker_id": 1, "skills": [1, 2, 3], "efficiency": 1.1},
        ],
        "jobs": [
            {
                "job_id": 0, "priority": 1, "due_date": 120.0,
                "operations": [
                    {"op_id": 0, "eligible_machines": [0, 1],
                     "processing_times": {"0": 10.0, "1": 12.0}, "setup_time": 2.0},
                    {"op_id": 1, "eligible_machines": [2, 3],
                     "processing_times": {"2": 8.0, "3": 9.0}, "setup_time": 1.5},
                ]
            },
            {
                "job_id": 1, "priority": 2, "due_date": 100.0,
                "operations": [
                    {"op_id": 0, "eligible_machines": [1, 2],
                     "processing_times": {"1": 7.0, "2": 6.5}, "setup_time": 1.0},
                    {"op_id": 1, "eligible_machines": [0, 3],
                     "processing_times": {"0": 11.0, "3": 10.0}, "setup_time": 2.5},
                ]
            },
            {
                "job_id": 2, "priority": 1, "due_date": 150.0,
                "operations": [
                    {"op_id": 0, "eligible_machines": [0, 2],
                     "processing_times": {"0": 9.0, "2": 8.0}, "setup_time": 1.5},
                    {"op_id": 1, "eligible_machines": [1, 3],
                     "processing_times": {"1": 14.0, "3": 11.0}, "setup_time": 2.0},
                ]
            },
        ]
    })

    EXAMPLE_HYPERPARAMS_JSON = json.dumps({
        "population_size"  : 91,
        "generations"      : 100,
        "crossover_rate"   : 0.9,
        "mutation_rate"    : 0.1,
        "num_divisions"    : 12,
        "objective_weights": [0.5, 0.3, 0.2],
        "random_seed"      : 42,
        "verbose"          : True,
    })

    result = run_fms_scheduling_agent(
        problem_json     = EXAMPLE_PROBLEM_JSON,
        hyperparams_json = EXAMPLE_HYPERPARAMS_JSON,
        print_report     = True,
    )

    print("\n" + "=" * 65)
    print("Agent Skill Result Summary")
    print("=" * 65)
    print(f"Algorithm          : {result.get('algorithm')}")
    print(f"Status             : {result['status']}")
    if result["status"] == "success":
        print(f"NSGA-III Params    : {result['nsga3_params']}")
        print(f"Pareto Front Size  : {result['pareto_front_size']}")
        if result["compromise_solution"]:
            objs = result["compromise_solution"]["objectives"]
            print(
                f"Compromise:\n"
                f"  f1 Makespan      = {objs[0]:.2f}\n"
                f"  f2 Energy (kWh)  = {objs[1]:.4f}\n"
                f"  f3 Fatigue       = {objs[2]:.5f}"
            )

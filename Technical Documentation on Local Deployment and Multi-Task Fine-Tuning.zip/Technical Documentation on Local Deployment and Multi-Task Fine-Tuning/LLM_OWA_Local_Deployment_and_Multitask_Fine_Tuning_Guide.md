# Local Ollama Deployment and Multi-Task Fine-Tuning Guide for LLM-OWA

## A Python-Based Technical Note for Industrial Peers

## 1. Purpose and Scope

This document provides a GitHub-ready technical configuration guide for the local deployment and multi-task fine-tuning of the integrated scheduling LLM (ISLLM) used in the LLM-OWA framework for collaborative scheduling in flexible manufacturing systems (FMS). It is written for practitioners who already understand industrial scheduling, manufacturing data pipelines, and Python-based AI engineering.

The document is intentionally positioned as an engineering note rather than a paper reproduction package. It does **not** include a full implementation, plant-specific prompts, private solver logic, confidential thresholds, or production secrets. Instead, it explains:

- how to deploy the LLM component locally in a Python stack,
- how to obtain open-source models through **Ollama**,
- how to organize the local serving layer for the LeaderAgent-centered architecture,
- how to build a **multi-task fine-tuning (MFT)** pipeline in Python,
- how to export the resulting model back into a local Ollama-based runtime.

This guide is aligned with two artifacts:

1. the paper's LLM-OWA / ISLLM methodology,
2. the current Python workflow, which already organizes the scheduling process into product mapping, scale analysis, LLM analysis, algorithm selection, solver execution, reporting, confirmation, and dynamic rescheduling.

---

## 2. Method Alignment

The paper defines a hierarchical orchestrator-workers architecture in which a planning-level **LeaderAgent** coordinates three execution-level agents:

- **ProdAgent** for production execution,
- **TransAgent** for AGV transport,
- **AuxAgent** for auxiliary and worker-facing operations.

The ISLLM acts as the cognitive core of the framework and supports three tasks:

1. **FMS knowledge and structured mapping**,
2. **algorithm selection and parameter design**,
3. **reasoning and decision making for abnormal events**.

The current Python workflow already exposes a directly usable engineering sequence:

1. `map_products`
2. `analyze_scale`
3. `llm_analysis`
4. `select_algorithm`
5. `execute_solving`
6. `generate_report`
7. `confirm_schedule`
8. `execute_rescheduling`

A practical mapping between the paper and the current workflow is shown below.

| Paper capability | Python workflow stage | Engineering role |
|---|---|---|
| Task 1: structured mapping | `map_products` | Convert workshop inputs into normalized executable scheduling semantics |
| Task 2: complexity analysis + solver choice + parameter design | `analyze_scale` + `llm_analysis` + `select_algorithm` + `execute_solving` | Match problem instances to suitable solvers and hyperparameters |
| Task 3: abnormal event reasoning and response | `confirm_schedule` + `execute_rescheduling` | Trigger diagnosis, strategy gating, and local/global rescheduling |

The most important deployment principle is to keep the **LeaderAgent as the only heavy LLM host** and leave execution-layer agents lightweight. This reduces replication overhead, simplifies maintenance, and keeps reasoning centralized.

---

## 3. Recommended Local Architecture

### 3.1 Logical Topology

A practical local deployment should separate the system into four layers:

#### A. Orchestration layer
- Python service hosting the **LeaderAgent**
- workflow engine (for example LangGraph or an equivalent state machine)
- memory store for plan state, event state, and rescheduling history
- schema validation and output control

#### B. Inference layer
- local **Ollama** runtime
- one primary instruct model for semantic reasoning
- one optional embedding model for knowledge retrieval
- structured output gateway for JSON-only generation

#### C. Optimization layer
- external scheduling solver(s)
- Optuna-based hyperparameter search service
- solver registry and instance-feature matcher

#### D. Edge execution layer
- machine adapters
- AGV adapters
- worker / AR interface adapters
- event collectors for anomalies and state deltas

### 3.2 Deployment Principle

Only the orchestration layer should invoke the main LLM. The execution-layer agents should exchange compact structured messages such as:

```json
{
  "resource_id": "agv_05",
  "event_type": "path_blockage",
  "severity": "medium",
  "affected_tasks": ["trans_J1O5"],
  "timestamp": "2026-03-19T10:00:00Z"
}
```

This is preferable to sending long free-form descriptions from the edge, because the paper's performance gains rely on centralized reasoning and lightweight edge agents rather than duplicated local LLM inference across machines, AGVs, and worker terminals.

---

## 4. Hardware and Runtime Envelope

The paper reports a reference setup with:

- **8 CPU cores**,
- **32 GB RAM**,
- **one 24 GB GPU**,
- **Python 3.8**,
- context length restricted to **4096 tokens**,
- max input length **3072**,
- max output length **512**,
- low-temperature decoding tuned for structured scheduling outputs.

That configuration is still a strong baseline for an initial industrial deployment when only one LeaderAgent serves one workshop cell or one low-concurrency scheduling service.

### 4.1 Recommended hardware tiers

| Tier | CPU | RAM | GPU | Intended use |
|---|---:|---:|---:|---|
| Development | 8 cores | 32 GB | 24 GB VRAM | single-cell testing, prompt/schema validation, LoRA inference |
| Pilot production | 16 cores | 64 GB | 24-48 GB VRAM | continuous plant-side scheduling, light concurrency |
| Centralized multi-cell | 16-32 cores | 64-128 GB | multi-GPU or service split | multiple workshops or higher event concurrency |

### 4.2 Runtime assumptions

The scheduling workflow is **event-driven**, not chatbot-style high-concurrency traffic. Therefore, the target is usually:

- low to moderate concurrency,
- predictable latency,
- stable JSON output,
- strong reproducibility across repeated scheduling calls.

For that reason, a conservative configuration is often better than a maximum-throughput configuration.

---

## 5. Python Environment

Although the paper reports Python 3.8, for a new repository a more practical recommendation is **Python 3.10 or 3.11**, while keeping 3.8 compatibility notes if backward compatibility is important.

### 5.1 Suggested package groups

#### Runtime and orchestration
- `ollama`
- `fastapi`
- `uvicorn`
- `pydantic`
- `langchain`
- `langgraph`
- `orjson`
- `optuna`

#### Training and fine-tuning
- `torch`
- `transformers`
- `datasets`
- `accelerate`
- `trl`
- `peft`
- `bitsandbytes`
- `safetensors`
- `sentencepiece`

#### Data engineering and validation
- `pandas`
- `numpy`
- `pyarrow`
- `scikit-learn`
- `jsonschema`

#### Observability and operations
- `prometheus-client`
- `loguru` or `structlog`
- `tenacity`

### 5.2 Example dependency grouping

```text
# runtime
ollama
fastapi
uvicorn
pydantic
langchain
langgraph
optuna
orjson

# training
transformers
datasets
accelerate
trl
peft
bitsandbytes
safetensors
sentencepiece

# data
pandas
numpy
pyarrow
scikit-learn
jsonschema
```

This document deliberately avoids pinning exact versions because version locking should follow the target CUDA, PyTorch, and GPU stack of the deployment site.

---

## 6. Obtaining Open-Source Models from Ollama

### 6.1 Role of Ollama in this stack

In this guide, **Ollama is the local model acquisition and serving layer**, not the full training framework. The intended workflow is:

1. pull a suitable open model from Ollama for local serving,
2. perform task development and inference validation locally,
3. fine-tune the corresponding trainable base family in a Python training stack,
4. import the resulting adapter or merged artifact back into Ollama for production serving.

This separation is important. It keeps deployment simple while retaining a standard Python training toolchain for MFT.

### 6.2 Recommended model families

For industrial scheduling, the most practical families are small or medium instruct models that:

- fit within a 24 GB VRAM envelope after quantization,
- produce stable structured outputs,
- support tool calling or structured-response control,
- remain usable under low-temperature decoding.

Typical candidates include:

- **Gemma 3** family,
- **Qwen3** family,
- **DeepSeek-R1** style reasoning variants when latency is acceptable.

For embeddings, use a lightweight embedding model such as:

- `embeddinggemma`,
- `qwen3-embedding`,
- or another Ollama-supported embedding model.

### 6.3 Example model acquisition commands

```bash
ollama pull gemma3
ollama pull qwen3
ollama pull embeddinggemma
```

You may standardize on one primary reasoning model and one embedding model for the first production release.

### 6.4 Selection guidance

For the specific methodology in the paper, the first practical production choice should favor:

- instruction-following stability,
- JSON compliance,
- lower inference variance,
- lower routing overhead than mixture-of-experts models when deterministic scheduling outputs matter more than general reasoning breadth.

---

## 7. Ollama Serving Configuration

### 7.1 Recommended serving policy

For initial deployment, run the LeaderAgent against one local Ollama service with a constrained context window and conservative decoding.

```bash
ollama serve
```

Recommended operating targets:

- `num_ctx`: 4096
- `temperature`: 0.2
- `top_p`: 0.9
- `top_k`: 40
- `num_predict`: 512 for structured task outputs

These values are aligned with the low-variance scheduling requirement and with the paper's deployment envelope.

### 7.2 Example Modelfile

```text
FROM gemma3
PARAMETER num_ctx 4096
PARAMETER temperature 0.2
PARAMETER top_p 0.9
PARAMETER top_k 40
PARAMETER num_predict 512
SYSTEM You are the decision core of a collaborative scheduling system. Output only validated JSON that matches the provided schema.
```

Create the custom runtime model with:

```bash
ollama create isllm-prod -f Modelfile
```

### 7.3 Structured outputs

For all three tasks, configure the inference layer to reject free-form answers and require **schema-constrained JSON**.

That means:

- Task 1 must output normalized structured mappings,
- Task 2 must output solver identifiers and validated hyperparameter sets,
- Task 3 must output structured diagnosis, RCI band, and strategy recommendation.

### 7.4 Tool invocation

The inference model should not solve the optimization problem directly. Instead, it should call external tools or internal Python functions for:

- solver dispatch,
- Optuna optimization,
- SKB retrieval,
- schedule simulation,
- rescheduling strategy execution.

This keeps the LLM in a decision and orchestration role rather than forcing it into direct numerical optimization.

---

## 8. Suggested Repository Layout

A GitHub repository built from this document can use the following structure:

```text
.
├── README.md
├── docs/
│   ├── local_deployment.md
│   ├── mft_method.md
│   └── schemas.md
├── configs/
│   ├── ollama/
│   ├── training/
│   └── serving/
├── data/
│   ├── raw/
│   ├── processed/
│   └── splits/
├── schemas/
│   ├── task1_mapping.schema.json
│   ├── task2_solver.schema.json
│   └── task3_reschedule.schema.json
├── training/
│   ├── prepare_data.py
│   ├── train_task_adapter.py
│   ├── fuse_adapters.py
│   ├── calibrate_model.py
│   └── evaluate_model.py
├── serving/
│   ├── leader_service.py
│   ├── inference_client.py
│   ├── skill_router.py
│   └── modelfiles/
├── orchestrator/
│   ├── workflow.py
│   ├── memory.py
│   └── state_models.py
├── skills/
│   ├── solver_registry.py
│   ├── optuna_runner.py
│   └── schedule_tools.py
└── examples/
    ├── task1_sample.json
    ├── task2_sample.json
    └── task3_sample.json
```

---

## 9. Data Organization for Multi-Task Fine-Tuning

The paper defines a manufacturing knowledge fabric (MKF) that converts heterogeneous workshop information into training-ready task data. In practice, the data pipeline should unify at least the following sources:

- MES orders,
- machine capability records,
- process routing tables,
- AGV path and transport logs,
- auxiliary operation logs,
- scheduling records,
- solver traces,
- anomaly and maintenance logs.

### 9.1 Task partitioning

The paper's MFT design uses three task groups:

#### Task 1: FMS knowledge and structured mapping
Goal:
- transform heterogeneous workshop inputs into normalized scheduling semantics.

Typical input:
- semi-structured order text,
- product constraints,
- current workshop resource snapshot.

Typical output:
- machine-readable scheduling objects,
- candidate machine sets,
- route constraints,
- auxiliary requirements.

#### Task 2: algorithm selection and parameter design
Goal:
- select a suitable solver and initialize its hyperparameters.

Typical input:
- instance feature vector,
- objective preference,
- scale tag,
- scheduling graph descriptors.

Typical output:
- solver identifier,
- hyperparameter configuration,
- expected trade-off profile.

#### Task 3: anomaly reasoning and rescheduling
Goal:
- diagnose abnormal events and return low-disruption response directives.

Typical input:
- anomaly event,
- current schedule fragment,
- resource state,
- coupling information.

Typical output:
- structured diagnosis,
- affected subgraph,
- RCI band,
- strategy recommendation,
- action directives.

### 9.2 Dataset cardinality reference

The paper reports the following task sample counts:

- **Task 1:** 1,450 samples
- **Task 2:** 628 samples
- **Task 3:** 2,654 samples

This distribution is reasonable for an initial MFT stack because Task 3 typically requires more coverage due to disturbance diversity.

### 9.3 Canonical JSON training format

A robust engineering approach is to normalize all training data into a message-based or instruction-output JSON format.

#### Task 1 example schema

```json
{
  "task": "mapping",
  "instruction": "Normalize the order and resource constraints into executable scheduling inputs.",
  "input": {
    "order_text": "...",
    "resource_snapshot": {"machines": [], "agvs": [], "workers": []}
  },
  "output": {
    "jobs": [],
    "operations": [],
    "candidate_resources": [],
    "constraints": []
  }
}
```

#### Task 2 example schema

```json
{
  "task": "solver_selection",
  "instruction": "Select a solver and initialize its parameters.",
  "input": {
    "instance_features": {
      "sigma": 0.0,
      "delta": 0.0,
      "avg_time": 0.0,
      "op_machine_ratio": 0.0,
      "available_machine_ratio": 0.0,
      "matrix_density": 0.0,
      "total_operations": 0
    },
    "objective_preference": "balanced",
    "scale": "medium"
  },
  "output": {
    "solver": "nsga2",
    "hyperparameters": {},
    "notes": ""
  }
}
```

#### Task 3 example schema

```json
{
  "task": "rescheduling",
  "instruction": "Diagnose the event and recommend a low-disruption response.",
  "input": {
    "event": {},
    "schedule_fragment": {},
    "resource_state": {},
    "influence_graph": {}
  },
  "output": {
    "diagnosis": {},
    "rci_band": "local_adjustment",
    "recommended_strategy": "repair_route_only",
    "action_directives": []
  }
}
```

### 9.4 Data engineering rules

Use the following rules before training:

- remove plant-specific identifiers unless needed for local deployment,
- normalize units for time, energy, and routing distances,
- version all schemas,
- split by **scenario type**, not only by row count,
- keep disturbance categories stratified,
- validate every output sample against JSON schemas before training.

---

## 10. Multi-Task Fine-Tuning Pipeline in Python

## 10.1 Why Python is still the right MFT layer

Ollama is excellent for local serving and model distribution, but **fine-tuning is better handled in Python** using the standard open-source training stack:

- `transformers`
- `trl`
- `peft`
- `accelerate`
- `bitsandbytes`

This also makes the process easier to explain in a public repository and easier for peers to reproduce.

## 10.2 Recommended training stages

### Stage A. Select one base family

Choose one model family and keep it fixed across all three tasks. Mixing tokenizers or model families inside one MFT process increases operational complexity and makes later Ollama packaging harder.

### Stage B. Train task-specific adapters

For each task, train a separate LoRA or QLoRA adapter:

- Adapter T1 for structured mapping
- Adapter T2 for solver selection and parameter design
- Adapter T3 for anomaly reasoning and rescheduling

A practical first choice is **QLoRA** because it reduces GPU memory pressure and fits the paper's lightweight deployment objective.

Recommended engineering defaults:

- 4-bit base loading,
- `nf4` quantization for training,
- bf16 compute when supported,
- gradient checkpointing enabled,
- sequence packing only if it does not break message boundaries.

### Stage C. Identify task-specific core parameters

The paper's central idea is that multi-task negative transfer can be reduced by protecting each task's most important update regions.

A practical implementation is:

1. compute parameter-update magnitude for each task adapter,
2. normalize by layer,
3. rank parameters by update amplitude,
4. select the top **k%** as task-core regions,
5. store a binary mask for each task.

The paper's sensitivity analysis suggests that moderate core ratios are preferable, with a practical range around **5% to 10%**.

### Stage D. Apply DARE-style fusion on non-core regions

After core-region identification, fuse the non-core task updates using a DARE-style procedure:

1. randomly drop non-core parameter updates with probability **p**,
2. rescale the retained updates,
3. merge them through task arithmetic or weighted combination,
4. keep protected core regions frozen during later calibration.

The paper's sensitivity analysis indicates that a moderate drop probability, around **0.2 to 0.3**, is a practical starting point.

### Stage E. Calibration

After fusion, run a calibration phase on a sampled mixed-task dataset:

- freeze task-core regions using the binary masks,
- fine-tune only the non-core fused regions,
- emphasize structured output validity,
- sample from all three tasks instead of letting one task dominate.

Calibration is not intended to relearn the tasks from scratch. Its role is to stabilize the fused model and reduce destructive interference.

### Stage F. Export

Export one of the following artifacts:

- **adapter-only artifact** for Ollama adapter-based packaging,
- **merged full checkpoint** for later quantization and Ollama registration.

---

## 11. Training Stack Details

### 11.1 Recommended training framework

A practical Python stack is:

- `transformers` for model and tokenizer loading,
- `trl.SFTTrainer` for supervised fine-tuning,
- `peft` for LoRA / QLoRA adapters,
- `accelerate` for launcher and distributed setup,
- `bitsandbytes` for memory-efficient 4-bit loading.

### 11.2 Suggested engineering defaults

These are engineering defaults, not paper-reported constants:

| Item | Suggested default |
|---|---|
| LoRA rank | 16 or 32 |
| LoRA alpha | 32 or 64 |
| LoRA dropout | 0.05 |
| Learning rate | `1e-4` to `2e-4` for adapter tuning |
| Warmup ratio | 0.03 |
| Weight decay | 0.0 to 0.1 |
| Effective batch size | choose per GPU memory budget |
| Max sequence length | 3072 to 4096 |

These values should be tuned against:

- JSON validity rate,
- tool-call correctness,
- solver-selection consistency,
- rescheduling stability.

### 11.3 Target modules

When supported by the selected base model architecture, attach LoRA to the main attention and projection layers first. If the task remains underfit, extend LoRA to selected MLP projections. Do not expand target modules blindly, because larger adaptation surfaces can increase interference during later fusion.

---

## 12. Exporting Fine-Tuned Artifacts Back to Ollama

### 12.1 Packaging options

After Python-side MFT, package the model into Ollama in one of two ways:

#### Option A. Adapter-based packaging
Use a Modelfile that references the same base model and attaches the adapter.

```text
FROM gemma3
ADAPTER ./adapters/isllm-task-fused
PARAMETER num_ctx 4096
PARAMETER temperature 0.2
SYSTEM You are the decision core of a collaborative scheduling system. Return schema-valid JSON only.
```

#### Option B. Merged checkpoint packaging
Merge the final adapter into the base model, export it into a format accepted by your serving toolchain, and register the resulting artifact with Ollama.

### 12.2 Compatibility note

Always keep the **same base family** between training and serving. Before standardizing the release, verify that the selected Ollama version supports the exact import path required by the trained artifact type.

### 12.3 Quantization

For local workshop-side deployment, 4-bit weight quantization is usually the most practical trade-off. If you observe degraded schema stability after quantization, compare:

- pre-quantization evaluation,
- post-quantization evaluation,
- and re-calibrated post-quantization evaluation.

Do not assume that quantization preserves task-level structured output behavior without testing.

---

## 13. Inference Policy for the Three Tasks

### 13.1 Task 1 policy

- low temperature
- mandatory JSON schema
- reject outputs missing required fields
- fallback to rule-based normalization when the model abstains

### 13.2 Task 2 policy

- solver identifiers must come from a controlled registry
- hyperparameters must be clipped to legal ranges before execution
- Optuna search should run as a tool, not as free-form text reasoning

### 13.3 Task 3 policy

- abnormal event classification must precede strategy selection
- diagnosis should include affected resource set and impacted plan fragment
- RCI should determine whether the action is local repair, partial rescheduling, or full rescheduling
- all action directives should be written in machine-consumable structured form

---

## 14. Evaluation and Release Criteria

A GitHub-ready technical release should define both **offline** and **online** acceptance criteria.

### 14.1 Offline model validation

Recommended checks:

- JSON validity rate per task
- schema conformance rate
- tool-routing accuracy
- solver-selection accuracy
- rescheduling directive correctness
- task confusion rate across the three tasks

### 14.2 Workflow-level validation

Recommended checks:

- percentage of successful full workflow runs
- schedule generation latency
- rescheduling latency under injected events
- failure-recovery consistency under repeated trials
- output reproducibility under fixed seeds

### 14.3 Industrial acceptance metrics

For a manufacturing-facing release, add operational metrics such as:

- percentage of schedules accepted by operators,
- percentage of anomaly cases handled without manual restart,
- average time to produce a valid recovery plan,
- rate of fallback to manual rules,
- variance across repeated runs for the same scenario.

---

## 15. Practical Design Recommendations

1. **Start with one central model.** Do not distribute separate LLM runtimes to every edge component in the first deployment.
2. **Force structured output everywhere.** Free-form reasoning is valuable for debugging, but production interfaces should consume JSON only.
3. **Treat Optuna and the solver as external skills.** The LLM should choose and configure them, not imitate them.
4. **Keep the context window bounded.** In production scheduling, shorter and more stable prompts usually outperform oversized contexts.
5. **Send state deltas, not full plant snapshots.** This reduces bandwidth and keeps rescheduling responsive.
6. **Use human override for high-impact out-of-distribution events.** Full autonomy is not required for a strong first release.
7. **Version the schemas and prompts independently from the model.** This makes debugging and rollback much easier.

---

## 16. Known Limitations

A realistic open-source technical note should acknowledge the same engineering limits highlighted by the paper:

- output-format anomalies can still occur,
- MFT increases validation complexity,
- deployment maintenance cost rises as workshop conditions evolve,
- LLM-plus-solver pipelines are not ideal for millisecond-level control loops.

In practice, LLM-OWA should therefore be deployed as a **planning and rescheduling layer**, not as a hard real-time motion-control layer.

---

## 17. Minimal Release Checklist

Before publishing the repository, verify that it contains:

- one clearly documented base model family,
- one Ollama-based serving path,
- one Python-based MFT path,
- schemas for Task 1 / Task 2 / Task 3,
- an evaluation checklist,
- a note distinguishing public open-source components from plant-specific private knowledge,
- a clear statement that Ollama is the runtime acquisition/serving layer and Python is the training layer.

---

## 18. Final Recommendation

For most industrial peers, the most practical first implementation is:

- **Gemma 3 or Qwen3 from Ollama** as the runtime reasoning model,
- **one Python-based MFT pipeline** built on Transformers + PEFT + TRL + Accelerate,
- **QLoRA adapters for each task**,
- **core-parameter masking + DARE-style fusion**,
- **schema-constrained JSON outputs**,
- **external Optuna and solver tools**,
- **LeaderAgent-only LLM hosting**,
- **lightweight event-driven edge adapters**.

This design remains faithful to the methodology of the paper while being realistic for a public GitHub release and for plant-side Python deployment.

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import List

from llm_owa_open.adapters.llm import MockLLMAdapter, OllamaChatAdapter
from llm_owa_open.workflow import LLMOWAWorkflow


def load_events(path: str | None):
    if not path:
        return []
    event_path = Path(path)
    if not event_path.exists():
        raise FileNotFoundError(f"Event file not found: {event_path}")
    return json.loads(event_path.read_text(encoding="utf-8"))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Open-source LLM-OWA engineering skeleton")
    parser.add_argument("--products", nargs="+", default=["J1", "J2", "J9"], help="Product IDs")
    parser.add_argument(
        "--preference",
        default="balanced",
        choices=["balanced", "time", "energy"],
        help="Optimization preference",
    )
    parser.add_argument("--events-file", default=None, help="JSON file with anomaly events")
    parser.add_argument("--auto-confirm", action="store_true", help="Skip interactive confirmation")
    parser.add_argument("--use-ollama", action="store_true", help="Use local Ollama-compatible endpoint")
    parser.add_argument("--ollama-model", default="llama3.1", help="Model name for Ollama")
    parser.add_argument("--output-dir", default="outputs", help="Directory for exported artifacts")
    return parser


def main(argv: List[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    llm = MockLLMAdapter()
    if args.use_ollama:
        llm = OllamaChatAdapter(model=args.ollama_model)

    workflow = LLMOWAWorkflow(llm=llm, output_dir=args.output_dir)
    state = workflow.run(
        product_ids=args.products,
        optimization_preference=args.preference,
        auto_confirm=args.auto_confirm,
        anomaly_plan=load_events(args.events_file),
    )

    print("\n=== Final Summary ===")
    print(json.dumps(state.to_public_dict(), indent=2))
    return 0 if not state.error else 1


if __name__ == "__main__":
    raise SystemExit(main())

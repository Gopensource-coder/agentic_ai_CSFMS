from __future__ import annotations

from pathlib import Path

from llm_owa_open.adapters.llm import MockLLMAdapter
from llm_owa_open.workflow import LLMOWAWorkflow


def test_smoke_run(tmp_path: Path) -> None:
    workflow = LLMOWAWorkflow(llm=MockLLMAdapter(), output_dir=str(tmp_path))
    state = workflow.run(
        product_ids=["J1", "J2", "J9"],
        optimization_preference="balanced",
        auto_confirm=True,
        anomaly_plan=[
            {
                "event_id": "evt-1",
                "event_type": "task_delay",
                "timestamp": 20,
                "severity": 0.4,
                "resource_id": "M2",
                "payload": {"delay_minutes": 8},
            }
        ],
    )
    assert not state.error
    assert state.schedule_result is not None
    assert state.schedule_result.operations
    assert (tmp_path / "schedule_result.json").exists()
    assert (tmp_path / "workflow_summary.json").exists()

# LLM-OWA Scheduling Report

- Products: J1, J2, J9
- Preference: balanced
- Complexity: medium
- Operations: 7
- Solver: Sanitized NSGA-II Skill
- Makespan: 125.25
- Total energy: 233.73
- Worker fatigue: 44.0

## LLM analysis
Sanitized analysis: complexity=medium, objective=balanced, operations=7, matrix_density=0.50. Use a reusable algorithm skill with explainable parameter templates.

## Notes
Private prompts, private thresholds, and private optimization traces are redacted.
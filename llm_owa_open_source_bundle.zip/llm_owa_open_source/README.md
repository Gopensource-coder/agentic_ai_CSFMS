# LLM-OWA Open-Source Engineering Skeleton

This repository turns the uploaded manuscript methodology and the uploaded `main.py` flow into a reusable Python engineering skeleton for an open-source release.

## Design goals

- Keep the original eight-step workflow shape.
- Map the paper into three production tasks:
  - Task 1: structured mapping of workshop knowledge.
  - Task 2: algorithm skill orchestration and parameter design.
  - Task 3: anomaly reasoning and rescheduling.
- Keep the orchestrator-workers architecture:
  - `LeaderAgent`
  - `ProdAgent`
  - `TransAgent`
  - `AuxAgent`
- Hide private prompts, private routing policies, private thresholds, private datasets, and private optimization tricks behind explicit placeholders.
- Run without external dependencies by default.

## Repository layout

```text
llm_owa_open/
  adapters/          # LLM adapters, including mock and Ollama-style HTTP adapter
  agents/            # LeaderAgent and execution-level agents
  data/              # Sanitized sample knowledge base
  knowledge/         # Task 1: structured mapping and scale analysis
  rescheduling/      # Task 3: diagnosis, RCI, strategy selection, monitoring
  scheduling/        # Deterministic demo solver and data export
  skills/            # Task 2: solver skill registry and parameter design
  contracts.py       # Shared dataclasses
  config.py          # Open-source config with redacted placeholders
  reporting.py       # Report generation
  state.py           # Workflow state
  workflow.py        # Eight-step engineering workflow
main_open_source.py  # CLI entry point
examples/            # Sample anomaly events
tests/               # Smoke test
```

## What is intentionally redacted

The following production assets are intentionally hidden and replaced with placeholders:

- Private prompt library used by the planning agent.
- Private scheduling knowledge base and industrial routing details.
- Proprietary solver ranking logic and tuning traces.
- Sensitive anomaly thresholds and decision templates.
- Real workshop identifiers, logs, and deployment endpoints.

Replace the placeholders in `llm_owa_open/config.py` and implement the integration points in the adapters and skills modules before a production deployment.

## How the paper maps into code

| Paper concept | Code module |
| --- | --- |
| OWA architecture | `agents/orchestrator.py`, `agents/workers.py` |
| Task 1: structured mapping | `knowledge/mapper.py` |
| Task 2: algorithm skills | `skills/algorithm_registry.py`, `skills/parameter_designer.py` |
| Task 3: anomaly reasoning and rescheduling | `rescheduling/anomaly.py` |
| Self-coordination loop | `rescheduling/monitor.py`, `workflow.py` |
| Main eight-step flow | `workflow.py` |

## Run the demo

```bash
python main_open_source.py --products J1 J2 J9 --preference balanced --auto-confirm --events-file examples/sample_events.json
```

## Notes

- The default execution uses a mock LLM adapter for deterministic local testing.
- To connect to a local open-source model service, replace the adapter in `main_open_source.py` with `OllamaChatAdapter`.
- The scheduling engine is a deterministic and explainable demo solver, not the private production optimizer.

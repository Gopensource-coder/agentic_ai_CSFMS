from __future__ import annotations

import json
from pathlib import Path
from typing import List

from .state import WorkflowState


class ReportBuilder:
    """Generate human-readable artifacts for the engineering workflow."""

    def build(self, state: WorkflowState) -> str:
        lines: List[str] = []
        lines.append("# LLM-OWA Scheduling Report")
        lines.append("")
        lines.append(f"- Products: {', '.join(state.product_ids)}")
        lines.append(f"- Preference: {state.optimization_preference}")
        if state.scale_info:
            lines.append(f"- Complexity: {state.scale_info.complexity_tag}")
            lines.append(f"- Operations: {state.scale_info.total_operations}")
        if state.selected_algorithm:
            lines.append(f"- Solver: {state.selected_algorithm.solver_name}")
        if state.schedule_result:
            lines.append(f"- Makespan: {state.schedule_result.makespan}")
            lines.append(f"- Total energy: {state.schedule_result.total_energy}")
            lines.append(f"- Worker fatigue: {state.schedule_result.worker_fatigue}")
        lines.append("")
        lines.append("## LLM analysis")
        lines.append(state.llm_analysis or "No LLM analysis available.")
        lines.append("")
        lines.append("## Notes")
        lines.append("Private prompts, private thresholds, and private optimization traces are redacted.")
        return "\n".join(lines)

    def save(self, state: WorkflowState, output_dir: str) -> None:
        path = Path(output_dir)
        path.mkdir(parents=True, exist_ok=True)
        report_path = path / "scheduling_report.md"
        report_path.write_text(self.build(state), encoding="utf-8")

        summary_path = path / "workflow_summary.json"
        summary_path.write_text(json.dumps(state.to_public_dict(), indent=2), encoding="utf-8")

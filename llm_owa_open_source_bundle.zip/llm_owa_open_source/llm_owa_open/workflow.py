from __future__ import annotations

from pathlib import Path
from typing import Iterable, List

from .adapters.llm import BaseLLMAdapter
from .agents.orchestrator import LeaderAgent
from .agents.workers import ExecutionLayer
from .config import OpenSourceSettings
from .knowledge.mapper import ScaleAnalyzer, StructuredMapper
from .reporting import ReportBuilder
from .rescheduling.monitor import MonitoringPreview
from .scheduling.engine import DeterministicSchedulingEngine
from .state import WorkflowState


class LLMOWAWorkflow:
    """Eight-step workflow aligned with the uploaded `main.py` shape."""

    def __init__(self, llm: BaseLLMAdapter, output_dir: str = "outputs") -> None:
        self.settings = OpenSourceSettings(output_dir=output_dir)
        self.mapper = StructuredMapper()
        self.scale_analyzer = ScaleAnalyzer()
        self.leader = LeaderAgent(llm=llm)
        self.engine = DeterministicSchedulingEngine()
        self.report_builder = ReportBuilder()
        self.execution_layer = ExecutionLayer()
        self.monitor_preview = MonitoringPreview()

    def run(
        self,
        product_ids: List[str],
        optimization_preference: str = "balanced",
        auto_confirm: bool = True,
        anomaly_plan: Iterable[dict] | None = None,
    ) -> WorkflowState:
        state = WorkflowState(product_ids=product_ids, optimization_preference=optimization_preference)
        events = list(anomaly_plan or [])

        try:
            self._map_products_node(state)
            self._analyze_scale_node(state)
            self._llm_analysis_node(state)
            self._select_algorithm_node(state)
            self._execute_solving_node(state)
            self._generate_report_node(state)
            self._confirm_schedule_node(state, auto_confirm=auto_confirm)
            if state.schedule_confirmed:
                self._execute_rescheduling_node(state, raw_events=events)
            self._persist_artifacts(state)
        except Exception as exc:
            state.error = str(exc)
            state.log(f"Workflow failed: {state.error}")
        return state

    def _map_products_node(self, state: WorkflowState) -> None:
        state.current_step = "mapping"
        state.products_mapping = self.mapper.map_products(state.product_ids)
        state.log(
            f"Mapped {len(state.products_mapping.valid_product_ids)} valid products and "
            f"{len(state.products_mapping.invalid_product_ids)} invalid products."
        )

    def _analyze_scale_node(self, state: WorkflowState) -> None:
        state.current_step = "scale_analysis"
        if not state.products_mapping:
            raise RuntimeError("Product mapping is missing.")
        state.scale_info = self.scale_analyzer.analyze(state.products_mapping)
        state.log(f"Analyzed problem scale: {state.scale_info.complexity_tag}.")

    def _llm_analysis_node(self, state: WorkflowState) -> None:
        state.current_step = "llm_analysis"
        if not state.scale_info:
            raise RuntimeError("Scale analysis is missing.")
        state.llm_analysis = self.leader.analyze_problem(state.scale_info, state.optimization_preference)
        state.log("Generated LLM analysis.")

    def _select_algorithm_node(self, state: WorkflowState) -> None:
        state.current_step = "algorithm_selection"
        if not state.scale_info:
            raise RuntimeError("Scale analysis is missing.")
        state.selected_algorithm = self.leader.select_algorithm(
            scale=state.scale_info,
            llm_analysis=state.llm_analysis,
            objective_preference=state.optimization_preference,
        )
        state.log(f"Selected solver {state.selected_algorithm.solver_id}.")

    def _execute_solving_node(self, state: WorkflowState) -> None:
        state.current_step = "solving"
        if not state.products_mapping or not state.selected_algorithm:
            raise RuntimeError("Mapping or algorithm decision is missing.")
        schedule, exec_time = self.engine.solve(
            mapping=state.products_mapping,
            parameters=state.selected_algorithm.parameters,
            objective_preference=state.optimization_preference,
        )
        state.schedule_result = schedule
        state.execution_time = exec_time
        preview = self.execution_layer.build_preview(schedule.operations)
        state.log(f"Schedule solved in {exec_time:.3f} seconds.")
        state.log(f"Execution preview: {preview}")

    def _generate_report_node(self, state: WorkflowState) -> None:
        state.current_step = "reporting"
        state.report = self.report_builder.build(state)
        state.log("Generated scheduling report.")

    def _confirm_schedule_node(self, state: WorkflowState, auto_confirm: bool) -> None:
        state.current_step = "confirmation"
        state.schedule_confirmed = auto_confirm
        state.log(f"Schedule confirmed={state.schedule_confirmed}.")

    def _execute_rescheduling_node(self, state: WorkflowState, raw_events: List[dict]) -> None:
        state.current_step = "rescheduling"
        if not state.products_mapping or not state.schedule_result:
            raise RuntimeError("Schedule data is missing.")
        monitor = self.monitor_preview.summarize(state.schedule_result, raw_events)
        state.log(f"Monitoring preview: {monitor}")
        state.rescheduling_result = self.leader.reschedule(
            mapping=state.products_mapping,
            schedule=state.schedule_result,
            events=raw_events,
        )
        if state.rescheduling_result:
            state.schedule_result = state.rescheduling_result[-1].updated_schedule
        state.log(f"Processed {len(state.rescheduling_result)} rescheduling events.")

    def _persist_artifacts(self, state: WorkflowState) -> None:
        output_dir = self.settings.output_dir
        Path(output_dir).mkdir(parents=True, exist_ok=True)
        if state.schedule_result:
            self.engine.save(state.schedule_result, output_dir=output_dir)
        self.report_builder.save(state, output_dir=output_dir)

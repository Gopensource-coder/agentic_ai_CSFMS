from __future__ import annotations

import copy
import math
from dataclasses import replace
from typing import Dict, Iterable, List, Tuple

from ..adapters.llm import BaseLLMAdapter
from ..config import OpenSourceSettings
from ..contracts import (
    AnomalyEvent,
    DiagnosisReport,
    MappingResult,
    RescheduleDecision,
    ScheduleOperation,
    ScheduleResult,
)
from ..knowledge.mapper import StructuredMapper
from ..scheduling.engine import DeterministicSchedulingEngine


class AnomalyReasoner:
    """Task 3: diagnose disturbances and compute a sanitized RCI."""

    def __init__(self, settings: OpenSourceSettings | None = None) -> None:
        self.settings = settings or OpenSourceSettings()

    def diagnose(self, schedule: ScheduleResult, event: AnomalyEvent) -> DiagnosisReport:
        remaining = [op for op in schedule.operations if op.start_time >= event.timestamp]
        impacted, affected_resources = self._find_impacted(schedule, event)
        remaining_count = max(len(remaining), 1)
        impact_scale = min(len(impacted) / remaining_count, 1.0)
        coupling_strength = self._estimate_coupling(event, impacted)
        due_urgency = min(0.35 + event.severity * 0.65, 1.0)
        substitutability = self._estimate_substitutability(event, impacted)
        stability_cost = min(len(impacted) / max(len(schedule.operations), 1), 1.0)
        response_speed = min(event.severity + 0.2, 1.0)

        weights = self.settings.rci_weights
        raw = (
            weights["impact_scale"] * impact_scale
            + weights["coupling_strength"] * coupling_strength
            + weights["due_urgency"] * due_urgency
            + weights["substitutability"] * (1.0 - substitutability)
            + weights["stability_cost"] * stability_cost
            + weights["response_speed"] * response_speed
        )
        rci = 1.0 / (1.0 + math.exp(-4.0 * (raw - 0.5)))

        evidence = [
            f"Remaining operations after event: {len(remaining)}",
            f"Impacted operations: {len(impacted)}",
            f"Affected resources: {', '.join(affected_resources) if affected_resources else 'none'}",
        ]
        estimated_delay = self._estimate_delay(event)

        return DiagnosisReport(
            event_id=event.event_id,
            anomaly_type=event.event_type,
            estimated_delay=estimated_delay,
            affected_resources=affected_resources,
            affected_operations=[op.operation_id for op in impacted],
            impact_scale=round(impact_scale, 4),
            coupling_strength=round(coupling_strength, 4),
            due_urgency=round(due_urgency, 4),
            substitutability=round(substitutability, 4),
            stability_cost=round(stability_cost, 4),
            response_speed=round(response_speed, 4),
            rci=round(rci, 4),
            evidence=evidence,
        )

    def select_strategy(self, diagnosis: DiagnosisReport) -> str:
        thresholds = self.settings.rci_thresholds
        if diagnosis.rci < thresholds["local_adjustment"]:
            return "local_adjustment"
        if diagnosis.rci < thresholds["partial_rebuild"]:
            return "partial_rebuild"
        return "global_reschedule"

    def _find_impacted(self, schedule: ScheduleResult, event: AnomalyEvent) -> Tuple[List[ScheduleOperation], List[str]]:
        if event.event_type == "urgent_order":
            impacted = [op for op in schedule.operations if op.start_time >= event.timestamp]
            return impacted, ["scheduler"]

        impacted = []
        resources = []
        for op in schedule.operations:
            if op.start_time < event.timestamp:
                continue
            if event.resource_id and event.resource_id in {op.machine_id, op.agv_id, op.worker_id}:
                impacted.append(op)
        if event.resource_id:
            resources.append(event.resource_id)
        return impacted, resources

    def _estimate_coupling(self, event: AnomalyEvent, impacted: List[ScheduleOperation]) -> float:
        if event.event_type == "urgent_order":
            return 0.90
        if event.event_type == "resource_failure":
            return min(0.55 + 0.05 * len(impacted), 1.0)
        return min(0.30 + 0.04 * len(impacted), 1.0)

    def _estimate_substitutability(self, event: AnomalyEvent, impacted: List[ScheduleOperation]) -> float:
        if event.event_type == "urgent_order":
            return 0.40
        if not impacted:
            return 1.0
        alt_counts = []
        for op in impacted:
            alternatives = [machine for machine in op.candidate_machines if machine != op.machine_id]
            alt_counts.append(len(alternatives))
        max_alternatives = max(max(alt_counts), 1)
        return sum(alt_counts) / (len(alt_counts) * max_alternatives)

    def _estimate_delay(self, event: AnomalyEvent) -> float:
        if event.event_type == "resource_failure":
            return float(event.payload.get("recovery_minutes", self.settings.failure_recovery_minutes))
        if event.event_type == "urgent_order":
            return float(event.payload.get("expected_slack_consumption", 25.0))
        return float(event.payload.get("delay_minutes", self.settings.delay_buffer))


class ReschedulingController:
    """Apply event-driven rescheduling in a close-loop style."""

    def __init__(self, llm: BaseLLMAdapter, settings: OpenSourceSettings | None = None) -> None:
        self.llm = llm
        self.settings = settings or OpenSourceSettings()
        self.reasoner = AnomalyReasoner(settings=self.settings)
        self.engine = DeterministicSchedulingEngine()
        self.mapper = StructuredMapper()

    def run(self, mapping: MappingResult, schedule: ScheduleResult, raw_events: Iterable[dict]) -> List[RescheduleDecision]:
        events = [AnomalyEvent.from_dict(item) for item in raw_events]
        decisions: List[RescheduleDecision] = []
        current_schedule = schedule
        for event in events:
            diagnosis = self.reasoner.diagnose(schedule=current_schedule, event=event)
            strategy = self.reasoner.select_strategy(diagnosis)
            updated_schedule = self.apply_strategy(mapping=mapping, schedule=current_schedule, event=event, strategy=strategy, diagnosis=diagnosis)
            rationale = self.llm.explain_reschedule(
                {
                    "event_type": event.event_type,
                    "strategy": strategy,
                    "rci": diagnosis.rci,
                    "private_strategy_template": "<REDACTED>",
                }
            )
            directives = self._build_directives(event, diagnosis, strategy)
            decision = RescheduleDecision(
                event_id=event.event_id,
                strategy=strategy,
                rationale=rationale,
                directives=directives,
                updated_schedule=updated_schedule,
                diagnosis=diagnosis,
            )
            decisions.append(decision)
            current_schedule = updated_schedule
        return decisions

    def apply_strategy(
        self,
        mapping: MappingResult,
        schedule: ScheduleResult,
        event: AnomalyEvent,
        strategy: str,
        diagnosis: DiagnosisReport,
    ) -> ScheduleResult:
        if strategy == "local_adjustment":
            return self._local_shift(schedule, event, diagnosis)
        if strategy == "partial_rebuild":
            return self._partial_rebuild(schedule, event, diagnosis)
        return self._global_reschedule(mapping, schedule, event)

    def _local_shift(self, schedule: ScheduleResult, event: AnomalyEvent, diagnosis: DiagnosisReport) -> ScheduleResult:
        delay = diagnosis.estimated_delay
        updated_ops = []
        for op in schedule.operations:
            if op.start_time >= event.timestamp and self._is_affected(op, event):
                updated_ops.append(
                    replace(op, start_time=op.start_time + delay, end_time=op.end_time + delay)
                )
            else:
                updated_ops.append(copy.deepcopy(op))
        return self._rebuild_result(schedule, updated_ops, strategy="local_adjustment", event=event)

    def _partial_rebuild(self, schedule: ScheduleResult, event: AnomalyEvent, diagnosis: DiagnosisReport) -> ScheduleResult:
        delay = diagnosis.estimated_delay * 0.6
        updated_ops = []
        for op in schedule.operations:
            if op.start_time >= event.timestamp and self._is_affected(op, event):
                new_machine = op.machine_id
                for candidate in op.candidate_machines:
                    if candidate != event.resource_id:
                        new_machine = candidate
                        break
                updated_ops.append(
                    replace(
                        op,
                        machine_id=new_machine,
                        start_time=op.start_time + delay,
                        end_time=op.end_time + delay,
                    )
                )
            else:
                updated_ops.append(copy.deepcopy(op))
        return self._rebuild_result(schedule, updated_ops, strategy="partial_rebuild", event=event)

    def _global_reschedule(self, mapping: MappingResult, schedule: ScheduleResult, event: AnomalyEvent) -> ScheduleResult:
        product_ids = [job.job_id for job in mapping.jobs]
        if event.event_type == "urgent_order":
            urgent_job_id = str(event.payload.get("new_job_id", "UX1")).upper()
            if urgent_job_id not in product_ids:
                product_ids.append(urgent_job_id)
        refreshed_mapping = self.mapper.map_products(product_ids)
        rebuilt, _ = self.engine.solve(
            refreshed_mapping,
            parameters={"reschedule_mode": "global", "private_trace": "<REDACTED>"},
            objective_preference="balanced",
        )
        shift = max(event.timestamp * 0.15, 0.0)
        shifted_ops = [replace(op, start_time=op.start_time + shift, end_time=op.end_time + shift) for op in rebuilt.operations]
        return self._rebuild_result(rebuilt, shifted_ops, strategy="global_reschedule", event=event)

    def _is_affected(self, op: ScheduleOperation, event: AnomalyEvent) -> bool:
        if event.event_type == "urgent_order":
            return op.start_time >= event.timestamp
        if not event.resource_id:
            return op.start_time >= event.timestamp
        return event.resource_id in {op.machine_id, op.agv_id, op.worker_id}

    def _rebuild_result(self, original: ScheduleResult, operations: List[ScheduleOperation], strategy: str, event: AnomalyEvent) -> ScheduleResult:
        makespan = max((op.end_time for op in operations), default=0.0)
        total_energy = sum(op.energy_kwh for op in operations)
        worker_loads: Dict[str, float] = {}
        for op in operations:
            worker_loads.setdefault(op.worker_id, 0.0)
            worker_loads[op.worker_id] += op.setup_time
        average = sum(worker_loads.values()) / max(len(worker_loads), 1)
        fatigue = sum(abs(load - average) for load in worker_loads.values()) + sum(worker_loads.values())
        metadata = dict(original.metadata)
        metadata.update({
            "last_strategy": strategy,
            "last_event": event.event_id,
        })
        return ScheduleResult(
            operations=operations,
            makespan=round(makespan, 3),
            total_energy=round(total_energy, 3),
            worker_fatigue=round(fatigue, 3),
            metadata=metadata,
        )

    def _build_directives(self, event: AnomalyEvent, diagnosis: DiagnosisReport, strategy: str) -> List[str]:
        directives = [
            f"Acknowledge event {event.event_id} of type {event.event_type}.",
            f"Apply strategy {strategy} with RCI={diagnosis.rci:.3f}.",
        ]
        if diagnosis.affected_resources:
            directives.append(f"Notify affected resources: {', '.join(diagnosis.affected_resources)}.")
        if event.event_type == "urgent_order":
            directives.append("Inject the urgent order into the next planning cycle.")
        return directives

from __future__ import annotations

from typing import Dict, Iterable, List

from ..contracts import ScheduleResult


class MonitoringPreview:
    """Create lightweight monitoring summaries for demonstrations."""

    def summarize(self, schedule: ScheduleResult, raw_events: Iterable[dict]) -> Dict[str, List[str]]:
        events = list(raw_events)
        lines = [f"Scheduled operations: {len(schedule.operations)}", f"Incoming events: {len(events)}"]
        for item in events:
            lines.append(f"Event {item.get('event_id', 'unknown')}: {item.get('event_type', 'task_delay')}")
        return {"monitoring": lines}

from __future__ import annotations

from typing import Dict, List, Tuple

MACHINES = {
    "M1": {"energy_idle": 0.25},
    "M2": {"energy_idle": 0.22},
    "M3": {"energy_idle": 0.28},
    "M4": {"energy_idle": 0.19},
}

AGVS = {
    "AGV1": {"capacity": 1},
    "AGV2": {"capacity": 1},
}

WORKERS = {
    "W1": {"skills": ["S-A", "S-B"]},
    "W2": {"skills": ["S-B", "S-C"]},
}

SANITIZED_PRODUCTS: Dict[str, List[dict]] = {
    "J1": [
        {
            "operation_id": "J1-O1",
            "candidate_machines": ["M1", "M2"],
            "process_time": {"M1": 18.0, "M2": 20.0},
            "setup_skill": "S-A",
            "setup_time": 4.0,
            "energy_rate": 1.4,
        },
        {
            "operation_id": "J1-O2",
            "candidate_machines": ["M2", "M3"],
            "process_time": {"M2": 24.0, "M3": 21.0},
            "setup_skill": "S-B",
            "setup_time": 5.0,
            "energy_rate": 1.6,
        },
    ],
    "J2": [
        {
            "operation_id": "J2-O1",
            "candidate_machines": ["M1", "M4"],
            "process_time": {"M1": 16.0, "M4": 19.0},
            "setup_skill": "S-A",
            "setup_time": 3.0,
            "energy_rate": 1.2,
        },
        {
            "operation_id": "J2-O2",
            "candidate_machines": ["M3", "M4"],
            "process_time": {"M3": 27.0, "M4": 23.0},
            "setup_skill": "S-C",
            "setup_time": 6.0,
            "energy_rate": 1.8,
        },
    ],
    "J9": [
        {
            "operation_id": "J9-O1",
            "candidate_machines": ["M2", "M4"],
            "process_time": {"M2": 14.0, "M4": 17.0},
            "setup_skill": "S-B",
            "setup_time": 4.0,
            "energy_rate": 1.1,
        },
        {
            "operation_id": "J9-O2",
            "candidate_machines": ["M1", "M3"],
            "process_time": {"M1": 29.0, "M3": 22.0},
            "setup_skill": "S-C",
            "setup_time": 5.0,
            "energy_rate": 1.7,
        },
        {
            "operation_id": "J9-O3",
            "candidate_machines": ["M2", "M3"],
            "process_time": {"M2": 18.0, "M3": 20.0},
            "setup_skill": "S-B",
            "setup_time": 4.0,
            "energy_rate": 1.3,
        },
    ],
    "UX1": [
        {
            "operation_id": "UX1-O1",
            "candidate_machines": ["M1", "M2"],
            "process_time": {"M1": 11.0, "M2": 13.0},
            "setup_skill": "S-A",
            "setup_time": 2.0,
            "energy_rate": 1.0,
        },
        {
            "operation_id": "UX1-O2",
            "candidate_machines": ["M3", "M4"],
            "process_time": {"M3": 14.0, "M4": 12.0},
            "setup_skill": "S-C",
            "setup_time": 3.0,
            "energy_rate": 1.1,
        },
    ],
}

TRANSPORT_TIMES: Dict[Tuple[str, str], float] = {
    ("WH", "M1"): 3.0,
    ("WH", "M2"): 4.0,
    ("WH", "M3"): 5.0,
    ("WH", "M4"): 4.0,
    ("M1", "M2"): 2.0,
    ("M1", "M3"): 4.0,
    ("M1", "M4"): 3.0,
    ("M2", "M1"): 2.0,
    ("M2", "M3"): 2.0,
    ("M2", "M4"): 3.0,
    ("M3", "M1"): 4.0,
    ("M3", "M2"): 2.0,
    ("M3", "M4"): 2.0,
    ("M4", "M1"): 3.0,
    ("M4", "M2"): 3.0,
    ("M4", "M3"): 2.0,
}


def get_transport_time(source: str, target: str) -> float:
    if source == target:
        return 0.0
    return TRANSPORT_TIMES.get((source, target), 4.0)

from __future__ import annotations

from typing import Dict, List

from ..adapters.llm import BaseLLMAdapter
from ..contracts import AlgorithmDecision, MappingResult, RescheduleDecision, ScaleAnalysis, ScheduleResult
from ..rescheduling.anomaly import ReschedulingController
from ..skills.algorithm_registry import AlgorithmSkillRegistry
from ..skills.parameter_designer import ParameterDesigner


class LeaderAgent:
    """Planning-level orchestrator for the open-source OWA skeleton."""

    def __init__(self, llm: BaseLLMAdapter) -> None:
        self.llm = llm
        self.registry = AlgorithmSkillRegistry()
        self.parameter_designer = ParameterDesigner()
        self.memory: Dict[str, List[str]] = {
            "analysis": [],
            "decisions": [],
            "events": [],
        }

    def analyze_problem(self, scale: ScaleAnalysis, objective_preference: str) -> str:
        analysis = self.llm.analyze_scale(
            {
                **scale.to_dict(),
                "optimization_preference": objective_preference,
                "private_prompt_library": "<REDACTED>",
            }
        )
        self.memory["analysis"].append(analysis)
        return analysis

    def select_algorithm(
        self,
        scale: ScaleAnalysis,
        llm_analysis: str,
        objective_preference: str,
    ) -> AlgorithmDecision:
        skill = self.registry.select(scale=scale, llm_analysis=llm_analysis, objective_preference=objective_preference)
        parameters = self.parameter_designer.design(skill, scale, objective_preference)
        rationale = (
            f"Selected {skill.name} for complexity={scale.complexity_tag}, "
            f"objective={objective_preference}. Private ranking traces are redacted."
        )
        decision = self.registry.to_decision(skill, rationale, parameters)
        self.memory["decisions"].append(decision.solver_id)
        return decision

    def dispatch_plan(self, schedule: ScheduleResult) -> Dict[str, List[str]]:
        prod_messages = []
        trans_messages = []
        aux_messages = []
        for op in schedule.operations:
            prod_messages.append(
                f"Process {op.operation_id} on {op.machine_id} from {op.start_time:.1f} to {op.end_time:.1f}."
            )
            trans_messages.append(
                f"Move job {op.job_id} with {op.agv_id} before {op.start_time:.1f}."
            )
            aux_messages.append(
                f"Prepare setup skill {op.setup_skill} with {op.worker_id} for {op.operation_id}."
            )
        return {"prod": prod_messages, "trans": trans_messages, "aux": aux_messages}

    def reschedule(
        self,
        mapping: MappingResult,
        schedule: ScheduleResult,
        events: List[dict],
    ) -> List[RescheduleDecision]:
        controller = ReschedulingController(llm=self.llm)
        decisions = controller.run(mapping=mapping, schedule=schedule, raw_events=events)
        self.memory["events"].extend([decision.event_id for decision in decisions])
        return decisions

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List

from ..contracts import ScheduleOperation


@dataclass(slots=True)
class WorkerObservation:
    agent_id: str
    signals: List[str]


class BaseWorkerAgent:
    """Execution-level agent with a lightweight ReAct structure."""

    def __init__(self, agent_id: str) -> None:
        self.agent_id = agent_id

    def observe(self, op: ScheduleOperation) -> WorkerObservation:
        return WorkerObservation(agent_id=self.agent_id, signals=[f"Observe {op.operation_id}"])

    def reason(self, observation: WorkerObservation) -> str:
        return f"Reason over {len(observation.signals)} signals."

    def act(self, op: ScheduleOperation) -> str:
        return f"Execute action for {op.operation_id}."


class ProdAgent(BaseWorkerAgent):
    def act(self, op: ScheduleOperation) -> str:
        return f"Start machine task {op.operation_id} on {op.machine_id}."


class TransAgent(BaseWorkerAgent):
    def act(self, op: ScheduleOperation) -> str:
        return f"Dispatch {op.agv_id} for {op.job_id} before {op.start_time:.1f}."


class AuxAgent(BaseWorkerAgent):
    def act(self, op: ScheduleOperation) -> str:
        return f"Guide {op.worker_id} for setup skill {op.setup_skill}."


class ExecutionLayer:
    """Container for execution-level agents used by the self-coordination loop."""

    def __init__(self) -> None:
        self.prod = ProdAgent(agent_id="ProdAgent")
        self.trans = TransAgent(agent_id="TransAgent")
        self.aux = AuxAgent(agent_id="AuxAgent")

    def build_preview(self, operations: List[ScheduleOperation]) -> Dict[str, List[str]]:
        messages = {"prod": [], "trans": [], "aux": []}
        for op in operations[:5]:
            messages["prod"].append(self.prod.act(op))
            messages["trans"].append(self.trans.act(op))
            messages["aux"].append(self.aux.act(op))
        return messages

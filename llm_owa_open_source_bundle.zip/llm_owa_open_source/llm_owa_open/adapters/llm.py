from __future__ import annotations

import json
import urllib.error
import urllib.request
from abc import ABC, abstractmethod
from typing import Any, Dict


class BaseLLMAdapter(ABC):
    """Abstract LLM adapter for local open-source deployments."""

    @abstractmethod
    def analyze_scale(self, payload: Dict[str, Any]) -> str:
        raise NotImplementedError

    @abstractmethod
    def explain_reschedule(self, payload: Dict[str, Any]) -> str:
        raise NotImplementedError


class MockLLMAdapter(BaseLLMAdapter):
    """Deterministic adapter for local testing and CI."""

    def analyze_scale(self, payload: Dict[str, Any]) -> str:
        complexity = payload.get("complexity_tag", "medium")
        objective = payload.get("optimization_preference", "balanced")
        ops = payload.get("total_operations", 0)
        density = payload.get("matrix_density", 0.0)
        return (
            f"Sanitized analysis: complexity={complexity}, objective={objective}, "
            f"operations={ops}, matrix_density={density:.2f}. "
            "Use a reusable algorithm skill with explainable parameter templates."
        )

    def explain_reschedule(self, payload: Dict[str, Any]) -> str:
        event_type = payload.get("event_type", "task_delay")
        strategy = payload.get("strategy", "local_adjustment")
        rci = payload.get("rci", 0.0)
        return (
            f"Sanitized reasoning chain: event={event_type}, strategy={strategy}, "
            f"rci={rci:.3f}. Private rule details remain redacted in the open-source release."
        )


class OllamaChatAdapter(BaseLLMAdapter):
    """Minimal Ollama-compatible HTTP adapter using the standard library."""

    def __init__(self, model: str, base_url: str = "http://localhost:11434") -> None:
        self.model = model
        self.base_url = base_url.rstrip("/")

    def _post(self, system_prompt: str, user_prompt: str) -> str:
        body = {
            "model": self.model,
            "stream": False,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
        }
        request = urllib.request.Request(
            f"{self.base_url}/api/chat",
            data=json.dumps(body).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=30) as response:
                payload = json.loads(response.read().decode("utf-8"))
        except urllib.error.URLError as exc:
            raise RuntimeError(f"Failed to call Ollama endpoint: {exc}") from exc
        return str(payload.get("message", {}).get("content", "")).strip()

    def analyze_scale(self, payload: Dict[str, Any]) -> str:
        system_prompt = (
            "You are a planning agent for a manufacturing scheduling workflow. "
            "The private production prompt library is redacted. Return concise reasoning."
        )
        user_prompt = json.dumps(payload)
        return self._post(system_prompt, user_prompt)

    def explain_reschedule(self, payload: Dict[str, Any]) -> str:
        system_prompt = (
            "You are a rescheduling reasoning agent for a manufacturing workflow. "
            "The private strategy templates are redacted. Return concise reasoning."
        )
        user_prompt = json.dumps(payload)
        return self._post(system_prompt, user_prompt)

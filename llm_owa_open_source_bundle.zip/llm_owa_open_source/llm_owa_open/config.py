from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict

REDACTED = "<REDACTED_FOR_OPEN_SOURCE_RELEASE>"

OBJECTIVE_ALPHA = {
    "balanced": 0.5,
    "time": 0.7,
    "energy": 0.3,
}

PRIVATE_ASSETS = {
    "prompt_library": REDACTED,
    "private_skb": REDACTED,
    "solver_ranker": REDACTED,
    "strategy_templates": REDACTED,
    "industrial_threshold_profile": REDACTED,
}

DEFAULT_RCI_WEIGHTS = {
    "impact_scale": 0.20,
    "coupling_strength": 0.18,
    "due_urgency": 0.17,
    "substitutability": 0.15,
    "stability_cost": 0.16,
    "response_speed": 0.14,
}

DEFAULT_RCI_THRESHOLDS = {
    "local_adjustment": 0.35,
    "partial_rebuild": 0.65,
}

DEFAULT_DELAY_BUFFER = 12.0
DEFAULT_FAILURE_RECOVERY = 30.0


@dataclass(slots=True)
class OpenSourceSettings:
    """Open-source runtime settings with sanitized defaults."""

    output_dir: str = "outputs"
    alpha_map: Dict[str, float] = field(default_factory=lambda: dict(OBJECTIVE_ALPHA))
    rci_weights: Dict[str, float] = field(default_factory=lambda: dict(DEFAULT_RCI_WEIGHTS))
    rci_thresholds: Dict[str, float] = field(default_factory=lambda: dict(DEFAULT_RCI_THRESHOLDS))
    private_assets: Dict[str, str] = field(default_factory=lambda: dict(PRIVATE_ASSETS))
    delay_buffer: float = DEFAULT_DELAY_BUFFER
    failure_recovery_minutes: float = DEFAULT_FAILURE_RECOVERY

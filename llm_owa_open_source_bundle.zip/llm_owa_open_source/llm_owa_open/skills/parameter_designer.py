from __future__ import annotations

from typing import Dict

from ..contracts import ScaleAnalysis
from .algorithm_registry import AlgorithmSkill


class ParameterDesigner:
    """Task 2: produce sanitized parameter templates for solver invocation."""

    def design(self, skill: AlgorithmSkill, scale: ScaleAnalysis, objective_preference: str) -> Dict[str, float]:
        parameters = dict(skill.default_parameters)

        if scale.complexity_tag == "large":
            parameters["population_size"] = parameters.get("population_size", 80) + 40
            parameters["iterations"] = parameters.get("iterations", 100) + 60
        elif scale.complexity_tag == "medium":
            parameters["population_size"] = parameters.get("population_size", 80) + 20

        if objective_preference == "time":
            parameters["time_weight"] = 0.7
            parameters["energy_weight"] = 0.3
        elif objective_preference == "energy":
            parameters["time_weight"] = 0.3
            parameters["energy_weight"] = 0.7
        else:
            parameters["time_weight"] = 0.5
            parameters["energy_weight"] = 0.5

        parameters["private_optuna_trace"] = "<REDACTED>"
        return parameters

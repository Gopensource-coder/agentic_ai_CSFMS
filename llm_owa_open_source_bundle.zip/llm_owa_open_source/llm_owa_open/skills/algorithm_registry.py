from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List

from ..contracts import AlgorithmDecision, ScaleAnalysis


@dataclass(slots=True)
class AlgorithmSkill:
    skill_id: str
    name: str
    description: str
    supported_complexities: List[str]
    objective_bias: List[str]
    default_parameters: Dict[str, float] = field(default_factory=dict)


class AlgorithmSkillRegistry:
    """Task 2: register reusable algorithm skills for open-source use."""

    def __init__(self) -> None:
        self._skills = {
            "sanitized_nsga2": AlgorithmSkill(
                skill_id="sanitized_nsga2",
                name="Sanitized NSGA-II Skill",
                description="Reusable multi-objective skill for small and medium problem instances.",
                supported_complexities=["small", "medium"],
                objective_bias=["balanced", "time"],
                default_parameters={
                    "population_size": 80,
                    "iterations": 120,
                    "crossover_rate": 0.9,
                    "mutation_rate": 0.1,
                },
            ),
            "sanitized_nsga3": AlgorithmSkill(
                skill_id="sanitized_nsga3",
                name="Sanitized NSGA-III Skill",
                description="Reference-point driven skill for denser and larger instances.",
                supported_complexities=["medium", "large"],
                objective_bias=["balanced", "energy"],
                default_parameters={
                    "population_size": 120,
                    "iterations": 180,
                    "crossover_rate": 0.9,
                    "mutation_rate": 0.12,
                    "reference_divisions": 10,
                },
            ),
            "sanitized_memetic": AlgorithmSkill(
                skill_id="sanitized_memetic",
                name="Sanitized Memetic Skill",
                description="Energy-aware hybrid skill with a repair phase.",
                supported_complexities=["small", "medium", "large"],
                objective_bias=["energy"],
                default_parameters={
                    "population_size": 90,
                    "iterations": 140,
                    "local_search_depth": 3,
                },
            ),
        }

    def list_skills(self) -> Dict[str, AlgorithmSkill]:
        return dict(self._skills)

    def select(self, scale: ScaleAnalysis, llm_analysis: str, objective_preference: str) -> AlgorithmSkill:
        """Use a sanitized policy instead of the private ranking model."""

        complexity = scale.complexity_tag
        if objective_preference == "energy":
            return self._skills["sanitized_memetic"]
        if complexity == "large" or scale.matrix_density > 0.60:
            return self._skills["sanitized_nsga3"]
        return self._skills["sanitized_nsga2"]

    def to_decision(self, skill: AlgorithmSkill, rationale: str, parameters: Dict[str, float]) -> AlgorithmDecision:
        return AlgorithmDecision(
            solver_id=skill.skill_id,
            solver_name=skill.name,
            rationale=rationale,
            parameters=parameters,
        )

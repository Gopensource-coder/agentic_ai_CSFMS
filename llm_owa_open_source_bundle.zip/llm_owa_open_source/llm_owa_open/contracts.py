from __future__ import annotations

from dataclasses import asdict, dataclass, field
from statistics import mean
from typing import Any, Dict, List, Optional


@dataclass(slots=True)
class ResourceUnit:
    resource_id: str
    resource_type: str
    status: str = "available"
    attributes: Dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class NormalizedOperation:
    job_id: str
    operation_id: str
    sequence_index: int
    candidate_machines: List[str]
    process_times: Dict[str, float]
    setup_skill: str
    setup_time: float
    energy_rate: float

    def default_process_time(self) -> float:
        values = list(self.process_times.values())
        return float(mean(values)) if values else 0.0


@dataclass(slots=True)
class NormalizedJob:
    job_id: str
    priority: int
    due_time: Optional[float]
    operations: List[NormalizedOperation]
    tags: List[str] = field(default_factory=list)


@dataclass(slots=True)
class MappingResult:
    valid_product_ids: List[str]
    invalid_product_ids: List[str]
    jobs: List[NormalizedJob]
    machines: List[ResourceUnit]
    agvs: List[ResourceUnit]
    workers: List[ResourceUnit]
    knowledge_refs: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class ScaleAnalysis:
    total_jobs: int
    total_operations: int
    total_machines: int
    total_agvs: int
    total_workers: int
    time_dispersion: float
    time_difference: float
    average_time: float
    job_resource_ratio: float
    available_resources_per_operation: float
    matrix_density: float
    complexity_tag: str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class AlgorithmDecision:
    solver_id: str
    solver_name: str
    rationale: str
    parameters: Dict[str, Any]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class ScheduleOperation:
    job_id: str
    operation_id: str
    sequence_index: int
    machine_id: str
    agv_id: str
    worker_id: str
    setup_skill: str
    start_time: float
    end_time: float
    process_time: float
    setup_time: float
    transport_time: float
    energy_kwh: float
    candidate_machines: List[str] = field(default_factory=list)

    def to_gantt_dict(self) -> Dict[str, Any]:
        return {
            "job": self.job_id,
            "operation": self.operation_id,
            "machine": self.machine_id,
            "agv": self.agv_id,
            "worker": self.worker_id,
            "start": round(self.start_time, 2),
            "end": round(self.end_time, 2),
            "transport_time": round(self.transport_time, 2),
            "setup_time": round(self.setup_time, 2),
            "energy_kwh": round(self.energy_kwh, 2),
        }


@dataclass(slots=True)
class ScheduleResult:
    operations: List[ScheduleOperation]
    makespan: float
    total_energy: float
    worker_fatigue: float
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def gantt_data(self) -> List[Dict[str, Any]]:
        return [operation.to_gantt_dict() for operation in self.operations]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "operations": [asdict(operation) for operation in self.operations],
            "makespan": round(self.makespan, 3),
            "total_energy": round(self.total_energy, 3),
            "worker_fatigue": round(self.worker_fatigue, 3),
            "metadata": self.metadata,
            "gantt_data": self.gantt_data,
        }


@dataclass(slots=True)
class AnomalyEvent:
    event_id: str
    event_type: str
    timestamp: float
    severity: float
    resource_id: Optional[str] = None
    payload: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, raw: Dict[str, Any]) -> "AnomalyEvent":
        return cls(
            event_id=str(raw.get("event_id", "event-unknown")),
            event_type=str(raw.get("event_type", "task_delay")),
            timestamp=float(raw.get("timestamp", 0.0)),
            severity=float(raw.get("severity", 0.5)),
            resource_id=raw.get("resource_id"),
            payload=dict(raw.get("payload", {})),
        )

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class DiagnosisReport:
    event_id: str
    anomaly_type: str
    estimated_delay: float
    affected_resources: List[str]
    affected_operations: List[str]
    impact_scale: float
    coupling_strength: float
    due_urgency: float
    substitutability: float
    stability_cost: float
    response_speed: float
    rci: float
    evidence: List[str]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class RescheduleDecision:
    event_id: str
    strategy: str
    rationale: str
    directives: List[str]
    updated_schedule: ScheduleResult
    diagnosis: DiagnosisReport

    def to_dict(self) -> Dict[str, Any]:
        payload = asdict(self)
        payload["updated_schedule"] = self.updated_schedule.to_dict()
        payload["diagnosis"] = self.diagnosis.to_dict()
        return payload

from __future__ import annotations

import json
from pathlib import Path
from statistics import mean
from typing import Dict, List, Tuple

from ..config import OBJECTIVE_ALPHA
from ..contracts import MappingResult, ScheduleOperation, ScheduleResult
from ..data.sanitized_knowledge import get_transport_time


class DeterministicSchedulingEngine:
    """Explainable demo solver for the open-source release."""

    def solve(self, mapping: MappingResult, parameters: Dict[str, float], objective_preference: str) -> Tuple[ScheduleResult, float]:
        machine_available = {resource.resource_id: 0.0 for resource in mapping.machines}
        agv_available = {resource.resource_id: 0.0 for resource in mapping.agvs}
        worker_available = {resource.resource_id: 0.0 for resource in mapping.workers}
        worker_skills = {resource.resource_id: set(resource.attributes.get("skills", [])) for resource in mapping.workers}
        previous_location = {job.job_id: "WH" for job in mapping.jobs}
        previous_end = {job.job_id: 0.0 for job in mapping.jobs}

        operations: List[ScheduleOperation] = []
        alpha = OBJECTIVE_ALPHA.get(objective_preference, 0.5)

        jobs = sorted(mapping.jobs, key=lambda job: (job.priority, job.job_id))
        for job in jobs:
            for op in job.operations:
                machine_id, transport_time, ready_for_setup = self._select_machine(
                    op=op,
                    machine_available=machine_available,
                    previous_location=previous_location[job.job_id],
                    previous_end=previous_end[job.job_id],
                )
                agv_id, agv_finish = self._select_agv(agv_available, previous_end[job.job_id], transport_time)
                worker_id, worker_start = self._select_worker(
                    worker_available=worker_available,
                    worker_skills=worker_skills,
                    skill=op.setup_skill,
                    baseline=max(ready_for_setup, agv_finish, machine_available[machine_id]),
                )
                process_start = max(worker_start + op.setup_time, machine_available[machine_id])
                process_time = op.process_times[machine_id]
                process_end = process_start + process_time
                energy = process_time * op.energy_rate * (1.0 + (1.0 - alpha) * 0.10)

                operations.append(
                    ScheduleOperation(
                        job_id=job.job_id,
                        operation_id=op.operation_id,
                        sequence_index=op.sequence_index,
                        machine_id=machine_id,
                        agv_id=agv_id,
                        worker_id=worker_id,
                        setup_skill=op.setup_skill,
                        start_time=worker_start,
                        end_time=process_end,
                        process_time=process_time,
                        setup_time=op.setup_time,
                        transport_time=transport_time,
                        energy_kwh=energy,
                        candidate_machines=list(op.candidate_machines),
                    )
                )

                machine_available[machine_id] = process_end
                agv_available[agv_id] = agv_finish
                worker_available[worker_id] = worker_start + op.setup_time
                previous_end[job.job_id] = process_end
                previous_location[job.job_id] = machine_id

        makespan = max((item.end_time for item in operations), default=0.0)
        total_energy = sum(item.energy_kwh for item in operations)
        worker_loads = {worker_id: 0.0 for worker_id in worker_available}
        for item in operations:
            worker_loads[item.worker_id] += item.setup_time
        average_load = mean(worker_loads.values()) if worker_loads else 0.0
        fatigue = sum(abs(load - average_load) for load in worker_loads.values()) + sum(worker_loads.values())

        result = ScheduleResult(
            operations=operations,
            makespan=round(makespan, 3),
            total_energy=round(total_energy, 3),
            worker_fatigue=round(fatigue, 3),
            metadata={
                "engine": "DeterministicSchedulingEngine",
                "parameters": parameters,
                "objective_preference": objective_preference,
            },
        )
        execution_time = round(0.02 * len(operations), 3)
        return result, execution_time

    def save(self, schedule: ScheduleResult, output_dir: str) -> Path:
        path = Path(output_dir)
        path.mkdir(parents=True, exist_ok=True)
        target = path / "schedule_result.json"
        target.write_text(json.dumps(schedule.to_dict(), indent=2), encoding="utf-8")
        return target

    def _select_machine(
        self,
        op,
        machine_available: Dict[str, float],
        previous_location: str,
        previous_end: float,
    ) -> Tuple[str, float, float]:
        best_machine = op.candidate_machines[0]
        best_transport = get_transport_time(previous_location, best_machine)
        best_ready = max(previous_end + best_transport, machine_available[best_machine])
        best_score = best_ready + op.process_times[best_machine]

        for machine_id in op.candidate_machines[1:]:
            transport = get_transport_time(previous_location, machine_id)
            ready = max(previous_end + transport, machine_available[machine_id])
            score = ready + op.process_times[machine_id]
            if score < best_score:
                best_machine = machine_id
                best_transport = transport
                best_ready = ready
                best_score = score

        return best_machine, best_transport, best_ready

    def _select_agv(
        self,
        agv_available: Dict[str, float],
        previous_end: float,
        transport_time: float,
    ) -> Tuple[str, float]:
        agv_id = min(agv_available, key=lambda key: agv_available[key])
        start = max(previous_end, agv_available[agv_id])
        finish = start + transport_time
        return agv_id, finish

    def _select_worker(
        self,
        worker_available: Dict[str, float],
        worker_skills: Dict[str, set],
        skill: str,
        baseline: float,
    ) -> Tuple[str, float]:
        eligible_workers = [worker_id for worker_id, skills in worker_skills.items() if skill in skills]
        if not eligible_workers:
            eligible_workers = list(worker_available)
        worker_id = min(eligible_workers, key=lambda key: max(worker_available[key], baseline))
        start = max(worker_available[worker_id], baseline)
        return worker_id, start

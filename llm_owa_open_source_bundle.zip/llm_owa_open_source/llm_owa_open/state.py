from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from .contracts import AlgorithmDecision, MappingResult, RescheduleDecision, ScaleAnalysis, ScheduleResult


@dataclass(slots=True)
class WorkflowState:
    product_ids: List[str]
    optimization_preference: str = "balanced"
    products_mapping: Optional[MappingResult] = None
    scale_info: Optional[ScaleAnalysis] = None
    llm_analysis: str = ""
    selected_algorithm: Optional[AlgorithmDecision] = None
    schedule_result: Optional[ScheduleResult] = None
    execution_time: float = 0.0
    report: str = ""
    schedule_confirmed: bool = False
    rescheduling_result: List[RescheduleDecision] = field(default_factory=list)
    current_step: str = ""
    error: str = ""
    logs: List[str] = field(default_factory=list)

    def log(self, message: str) -> None:
        self.logs.append(message)

    def to_public_dict(self) -> Dict[str, Any]:
        return {
            "product_ids": self.product_ids,
            "optimization_preference": self.optimization_preference,
            "current_step": self.current_step,
            "error": self.error,
            "llm_analysis": self.llm_analysis,
            "scale_info": self.scale_info.to_dict() if self.scale_info else None,
            "selected_algorithm": self.selected_algorithm.to_dict() if self.selected_algorithm else None,
            "schedule_result": self.schedule_result.to_dict() if self.schedule_result else None,
            "execution_time": round(self.execution_time, 3),
            "schedule_confirmed": self.schedule_confirmed,
            "rescheduling_result": [item.to_dict() for item in self.rescheduling_result],
            "logs": self.logs,
        }

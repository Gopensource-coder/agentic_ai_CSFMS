from __future__ import annotations

from statistics import mean, pstdev
from typing import Iterable, List

from ..contracts import MappingResult, NormalizedJob, NormalizedOperation, ResourceUnit, ScaleAnalysis
from ..data.sanitized_knowledge import AGVS, MACHINES, SANITIZED_PRODUCTS, WORKERS


class StructuredMapper:
    """Task 1: convert product IDs into a normalized problem model."""

    def map_products(self, product_ids: Iterable[str]) -> MappingResult:
        valid_product_ids: List[str] = []
        invalid_product_ids: List[str] = []
        jobs: List[NormalizedJob] = []

        for raw_product_id in product_ids:
            product_id = str(raw_product_id).strip().upper()
            route = SANITIZED_PRODUCTS.get(product_id)
            if not route:
                invalid_product_ids.append(product_id)
                continue

            operations = []
            for index, op in enumerate(route, start=1):
                operations.append(
                    NormalizedOperation(
                        job_id=product_id,
                        operation_id=op["operation_id"],
                        sequence_index=index,
                        candidate_machines=list(op["candidate_machines"]),
                        process_times=dict(op["process_time"]),
                        setup_skill=str(op["setup_skill"]),
                        setup_time=float(op["setup_time"]),
                        energy_rate=float(op["energy_rate"]),
                    )
                )

            jobs.append(
                NormalizedJob(
                    job_id=product_id,
                    priority=1 if product_id.startswith("UX") else 3,
                    due_time=None,
                    operations=operations,
                    tags=["sanitized-release"],
                )
            )
            valid_product_ids.append(product_id)

        machines = [ResourceUnit(resource_id=item, resource_type="machine", attributes=data) for item, data in MACHINES.items()]
        agvs = [ResourceUnit(resource_id=item, resource_type="agv", attributes=data) for item, data in AGVS.items()]
        workers = [ResourceUnit(resource_id=item, resource_type="worker", attributes=data) for item, data in WORKERS.items()]

        return MappingResult(
            valid_product_ids=valid_product_ids,
            invalid_product_ids=invalid_product_ids,
            jobs=jobs,
            machines=machines,
            agvs=agvs,
            workers=workers,
            knowledge_refs=["sanitized_skb:products", "sanitized_skb:resources"],
        )


class ScaleAnalyzer:
    """Compute a compact indicator vector for solver matching."""

    def analyze(self, mapping: MappingResult) -> ScaleAnalysis:
        operations = [op for job in mapping.jobs for op in job.operations]
        process_times = [t for op in operations for t in op.process_times.values()]

        total_jobs = len(mapping.jobs)
        total_operations = len(operations)
        total_machines = len(mapping.machines)
        total_agvs = len(mapping.agvs)
        total_workers = len(mapping.workers)
        total_resources = max(total_machines + total_agvs + total_workers, 1)

        average_time = mean(process_times) if process_times else 0.0
        time_dispersion = pstdev(process_times) / average_time if process_times and average_time else 0.0
        time_difference = (max(process_times) - min(process_times)) if process_times else 0.0
        job_resource_ratio = total_jobs / total_resources
        available_resources_per_operation = (
            mean(len(op.candidate_machines) for op in operations) if operations else 0.0
        )
        matrix_density = (
            sum(len(op.candidate_machines) for op in operations) / max(total_operations * total_machines, 1)
        )

        if total_operations >= 10 or matrix_density > 0.70:
            complexity_tag = "large"
        elif total_operations >= 6 or matrix_density > 0.50:
            complexity_tag = "medium"
        else:
            complexity_tag = "small"

        return ScaleAnalysis(
            total_jobs=total_jobs,
            total_operations=total_operations,
            total_machines=total_machines,
            total_agvs=total_agvs,
            total_workers=total_workers,
            time_dispersion=round(time_dispersion, 4),
            time_difference=round(time_difference, 4),
            average_time=round(average_time, 4),
            job_resource_ratio=round(job_resource_ratio, 4),
            available_resources_per_operation=round(available_resources_per_operation, 4),
            matrix_density=round(matrix_density, 4),
            complexity_tag=complexity_tag,
        )
